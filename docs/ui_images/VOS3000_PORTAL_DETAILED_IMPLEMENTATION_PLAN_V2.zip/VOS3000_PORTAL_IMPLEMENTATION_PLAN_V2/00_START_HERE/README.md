# VOS3000 Portal — Detailed Implementation Pack V2

This pack is intentionally execution-oriented.

## Coverage
- **18 implementation phases**
- **97 Admin pages**
- **45 Client pages**
- **142 total product pages**
- architecture, data, API, security, testing, operations and project-control files
- original product specifications and VOS source references
- `DESIGN.md` and `AGENTS.md`

## Start In This Order
1. `../IMPLEMENTATION_PLAN.md`
2. `../AGENTS.md`
3. `../DESIGN.md`
4. `../03_PHASES/PHASE_00_*`
5. `../04_PAGE_TODOS/ADMIN_ALL_97_PAGES_TODO.md`
6. `../04_PAGE_TODOS/CLIENT_ALL_45_PAGES_TODO.md`
7. relevant engineering/data/operations files

## Important
The VOS manual documents functions and client behavior, but it does not by itself prove a complete external API for every write operation. Any VOS mutation must stay capability-gated until verified against the installed build.
