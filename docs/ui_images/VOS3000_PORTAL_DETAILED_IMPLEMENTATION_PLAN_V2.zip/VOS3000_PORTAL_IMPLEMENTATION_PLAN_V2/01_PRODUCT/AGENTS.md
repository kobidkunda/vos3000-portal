# AGENTS.md

## Mission
Build the VOS3000 Admin + Customer Portal as a production telecom platform, not a demo.

Priorities:
1. correctness
2. tenant isolation
3. safe billing
4. reliable CDR ingestion
5. realtime observability
6. predictable UI

## Read First
Before coding any feature, read:
- `DESIGN.md`
- `IMPLEMENTATION_PLAN.md`
- the relevant `03_PHASES/PHASE_*.md`
- the relevant Admin/Client Product Design reference
- VOS source map/manual when touching VOS behavior

Never invent a VOS field, endpoint or write operation.

## Stack
- Next.js + TypeScript
- NestJS on Fastify
- PostgreSQL 18 + PgBouncer
- ClickHouse
- Redis
- Redpanda
- MinIO/S3
- Prometheus/Grafana/Loki

Data ownership:
- PostgreSQL = identity, customers, config, payments, RBAC, audit
- ClickHouse = CDR/history/analytics
- Redis = live state/cache/rate limits
- Redpanda = durable event pipeline

## Hard Architecture Rules
- Browser never talks to VOS directly.
- All VOS access goes through `VOS Adapter`.
- All customer reads are tenant-scoped server-side.
- All financial actions are idempotent and reconciled.
- Raw CDR is not stored primarily in PostgreSQL.
- Large exports are background jobs.
- Redis must be rebuildable.
- Unsupported VOS capabilities fail closed.

## Security
Mandatory:
- RBAC for admin mutations
- tenant isolation tests
- secrets never in frontend/logs
- customer DTOs exclude carrier/internal fields
- high-risk changes require audit + confirmation
- MFA/re-authentication where configured

## Money
Never use float arithmetic.
Provider callback flow:
`verify -> dedupe -> ledger -> VOS command -> readback/reconcile -> complete`

If VOS outcome is unknown, do not blindly retry.

## CDR
- durable ingest through Redpanda
- batch ClickHouse writes
- verified dedupe identity
- cursor pagination
- query limits
- rollups for dashboard analytics
- async CSV.gz/Parquet exports for huge ranges

## Realtime
Redis + WebSocket/SSE.
Always expose freshness.
If source is stale, show degraded—not stale green status.

## API
- `/api/v1`
- typed DTOs
- validation
- structured errors
- request IDs
- OpenAPI
- explicit admin/client projections
- rate limits and scope enforcement

## UI
Follow `DESIGN.md`.
Every page has:
- loading
- empty
- error
- forbidden
- degraded-source
- success states where applicable

## Audit
Audit every mutation to:
- users/RBAC
- accounts
- payments/balance
- gateways/IP/capacity
- rates/packages
- API keys/webhooks
- system settings
- live-call disconnect

## Tests
Critical features require:
- unit
- integration
- authorization
- cross-tenant negative
- failure/retry
- contract tests against non-production VOS
- performance/load tests for CDR paths

## Definition of Done
Done means:
- implementation complete
- permission model correct
- tenant isolation tested
- failure/degraded states present
- audit/logging present
- tests green
- docs/OpenAPI updated
- VOS behavior verified, not guessed
