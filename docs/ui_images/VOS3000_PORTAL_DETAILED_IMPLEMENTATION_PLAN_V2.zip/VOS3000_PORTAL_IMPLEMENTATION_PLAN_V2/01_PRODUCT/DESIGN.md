# DESIGN.md

## Product Direction
Carrier-grade telecom operations UI for VOS3000-backed Admin + Client portals.

The product must feel **dense, calm, fast, trustworthy and operational**. Data is the interface. Avoid decorative SaaS styling that reduces scan speed.

## Core Colors

### Brand
- Primary / Signal Blue: `#2563EB`
- Primary Hover: `#1D4ED8`
- Primary Soft: `#DBEAFE`
- Network / Realtime Cyan: `#06B6D4`
- Network Deep: `#0891B2`

### Light
- Background: `#F8FAFC`
- Surface: `#FFFFFF`
- Surface Subtle: `#F1F5F9`
- Border: `#E2E8F0`
- Border Strong: `#CBD5E1`
- Text Primary: `#0F172A`
- Text Secondary: `#475569`
- Text Muted: `#64748B`
- Text Disabled: `#94A3B8`

### Dark / NOC
- Background: `#080D17`
- Sidebar: `#0B1220`
- Surface: `#111827`
- Surface Elevated: `#172033`
- Surface Hover: `#1E293B`
- Border: `#253149`
- Border Strong: `#334155`
- Text Primary: `#F8FAFC`
- Text Secondary: `#CBD5E1`
- Text Muted: `#94A3B8`

### Semantic
- Success / Online: `#16A34A`
- Warning / Degraded: `#D97706`
- Danger / Offline / Error: `#DC2626`
- Pending: `#7C3AED`
- Disabled: `#64748B`
- Info: `#2563EB`
- Realtime: `#06B6D4`

Rules:
- Blue = primary action/link.
- Cyan = live/network/realtime.
- Green = success/healthy.
- Amber = warning/degraded.
- Red = critical/destructive.
- Never use semantic color decoratively.
- Status always has text/icon, never color alone.

## Typography
- UI: **Inter**
- Technical IDs: **IBM Plex Mono**
- Fallback: `system-ui, -apple-system, "Segoe UI", sans-serif`

Scale:
- Page title: 24/32, 700
- Section: 18/26, 600
- Card: 16/24, 600
- Body: 14/21, 400
- Table: 13/18, 400-500
- Label: 13/18, 500
- Helper: 12/17, 400
- Badge: 11-12/16, 600
- KPI: 28-32, 700
- Mono technical: 12-13/18, 500

Use `font-variant-numeric: tabular-nums` for money, rates, CPS, ASR, ACD, PDD, durations, timestamps and counts.

## Layout
Base spacing: 8px.
Allowed rhythm: 4 / 8 / 12 / 16 / 24 / 32 / 48 / 64.

- Admin sidebar: 248px
- Client sidebar: 232px
- Top bar: 56-64px
- Desktop page padding: 24px
- Mobile page padding: 16px
- Card padding: 16-24px
- Section gap: 24-32px

Breakpoints:
- Mobile `<768`
- Tablet `768-1023`
- Desktop `1024-1439`
- Wide `>=1440`

## Components
- Inputs/buttons: 36-40px desktop, >=44px touch target mobile.
- Input radius 6px.
- Button/card radius 8px.
- Modal radius 12px.
- Badges pill only.
- Prefer borders over heavy shadows.

### Tables
Default for CDR, gateways, customers, rates and billing:
- 13px body
- 40-44px rows
- sticky header when useful
- server-side filtering/sorting/pagination
- column chooser
- right-align numeric values
- mono for IP/Call-ID/request IDs
- no full red/green row backgrounds

### Navigation
Admin uses dark sidebar in light mode.
Client uses lighter, simpler navigation.

### Realtime
Every live page must show:
- live/degraded state
- last successful source refresh
- stream reconnect state
- stale-data warning

### Finance
- exact currency labels
- tabular numbers
- right-aligned values
- no “success” until backend reconciliation confirms

## Do
- keep the UI dense and aligned
- use semantic badges
- use tabular numerals
- use mono for technical identifiers
- build loading/empty/error/permission/degraded states
- show raw technical detail only where role permits

## Don't
- gradients inside operational UI
- glassmorphism
- oversized marketing typography
- excessive rounded cards
- more than one dominant CTA per action group
- unverified VOS fields or functions
- customer exposure of carrier/internal data
