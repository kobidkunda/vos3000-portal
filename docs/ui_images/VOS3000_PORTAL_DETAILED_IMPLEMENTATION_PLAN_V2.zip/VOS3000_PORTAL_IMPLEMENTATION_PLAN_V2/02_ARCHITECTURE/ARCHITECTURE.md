# Architecture

```text
Browser
  |
Nginx / TLS
  |
  +--> Next.js Web (/admin + /app)
  |
  +--> NestJS/Fastify Portal API
          |
          +--> PostgreSQL 18 + PgBouncer
          |      business state / RBAC / billing / audit
          |
          +--> ClickHouse
          |      CDR / historical analytics
          |
          +--> Redis
          |      live calls / gateway state / cache / rate limits
          |
          +--> Redpanda
          |      durable CDR/events/jobs
          |
          +--> MinIO/S3
          |      exports/reports
          |
          +--> VOS Adapter
                 |
                 +--> VOS3000 instance(s)
```

## Process Model
- `web`
- `api`
- `cdr-ingest`
- `cdr-consumer`
- `realtime-worker`
- `worker/scheduler`

One repository, separate deployable processes. Do not create unnecessary microservice repositories.

## Data Rules
- PostgreSQL = transactional truth.
- ClickHouse = high-volume CDR truth.
- Redis = rebuildable present-time projection.
- Redpanda = durable event transport/replay.
- VOS = authoritative telecom engine for supported account/routing/billing state.
