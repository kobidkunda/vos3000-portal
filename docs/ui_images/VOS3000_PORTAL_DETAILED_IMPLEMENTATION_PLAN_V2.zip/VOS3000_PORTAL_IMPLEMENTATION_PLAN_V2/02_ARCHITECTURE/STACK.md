# Stack

## Frontend
- Next.js
- TypeScript
- Tailwind CSS
- shadcn/ui
- TanStack Table
- React Hook Form + Zod
- ECharts/Recharts only after choosing one chart library consistently

## Backend
- NestJS
- Fastify adapter
- Zod/class-validator style validation — choose one consistent boundary strategy
- OpenAPI
- Pino structured logs

## Data
- PostgreSQL 18
- PgBouncer
- Drizzle ORM or explicit SQL repository layer for PostgreSQL
- ClickHouse native JS client
- Redis
- Redpanda
- MinIO/S3

## Operations
- Ubuntu
- Docker Compose initially
- Nginx
- Prometheus
- Grafana
- Loki

## Deferred
- Kubernetes until measured need
- Elasticsearch/OpenSearch until actual search requirement
- GraphQL
- service mesh
