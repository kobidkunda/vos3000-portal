# Deployment

Deploy order:
1. backup/health
2. PostgreSQL migrations
3. ClickHouse migrations
4. compatible workers
5. API
6. web
7. smoke tests
8. consumer lag check
9. CDR latest time
10. VOS adapter health
11. enable feature flags

Production images are immutable and commit-SHA tagged.
No production deploy directly from developer laptop.
