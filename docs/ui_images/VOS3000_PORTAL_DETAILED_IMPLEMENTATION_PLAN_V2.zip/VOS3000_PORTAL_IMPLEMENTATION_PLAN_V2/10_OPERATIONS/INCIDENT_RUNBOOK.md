# Incident Runbook

Critical scenarios:
- CDR ingest stopped
- Redpanda unavailable/disk full
- ClickHouse unavailable
- PostgreSQL unavailable
- Redis lost
- VOS adapter unavailable
- payment outcome unknown
- cross-tenant exposure
- rate deployment error

Rules:
- stop risky changes
- preserve request/event IDs
- disable financial/config writes when correctness uncertain
- never blindly replay without dedupe proof
- reconcile data after recovery
- document root cause and corrective tests
