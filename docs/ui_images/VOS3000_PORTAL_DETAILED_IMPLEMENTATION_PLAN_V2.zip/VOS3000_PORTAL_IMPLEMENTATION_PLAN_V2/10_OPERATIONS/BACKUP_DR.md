# Backup & DR

PostgreSQL:
- scheduled backups
- PITR if required
- clean restore tests

ClickHouse:
- schema + data backup
- restore representative partitions
- verify row counts/aggregates

Redpanda:
- durable buffer with retention sized to outage window
- not sole permanent CDR archive

Redis:
- rebuild live state from VOS

Object storage:
- protect retained invoices/statements
- exports may have expiry policy

Run restore drills. A configured but untested backup is not accepted.
