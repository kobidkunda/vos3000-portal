# Observability

Metrics:
- API rate/error/p95
- VOS adapter latency/errors/last success
- CDR received/s
- Redpanda lag/oldest age
- ClickHouse insert/query/merge/disk
- PostgreSQL connections/locks
- Redis memory/evictions
- report/webhook queues
- payment reconciliation backlog
- live collector freshness

Every critical alert includes impact, dashboard and runbook.
