# Complete Page-to-Phase Matrix

All product pages are represented. No page should be omitted from planning.

| Side | # | Group | Page | Route | Primary Phase |
|---|---:|---|---|---|---|
| Admin | 1 | Access & Identity | Admin Login | `/admin/login` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Admin | 2 | Access & Identity | MFA Challenge | `/admin/mfa` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Admin | 3 | Access & Identity | Forgot / Reset Password | `/admin/forgot-password` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Admin | 4 | Access & Identity | Admin Sessions & Devices | `/admin/settings/sessions` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 5 | Command Center | Executive Dashboard | `/admin` | 09 — Admin Portal Foundation |
| Admin | 6 | Command Center | NOC Live Operations | `/admin/noc` | 09 — Admin Portal Foundation |
| Admin | 7 | Command Center | System Health | `/admin/system/health` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 8 | Command Center | Alarm Center | `/admin/alarms` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 9 | Customers & Accounts | Customer Directory | `/admin/customers` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 10 | Customers & Accounts | Create Customer Wizard | `/admin/customers/new` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 11 | Customers & Accounts | Customer Overview | `/admin/customers/{customerId}` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 12 | Customers & Accounts | Customer Account Settings | `/admin/customers/{customerId}/account` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 13 | Customers & Accounts | Customer Balance & Adjustments | `/admin/customers/{customerId}/balance` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 14 | Customers & Accounts | Customer Packages | `/admin/customers/{customerId}/packages` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 15 | Customers & Accounts | Customer Authorizations | `/admin/customers/{customerId}/authorizations` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 16 | Customers & Accounts | Agent & Subaccount Tree | `/admin/customers/{customerId}/subaccounts` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 17 | Customers & Accounts | Customer Number Section Limits | `/admin/customers/{customerId}/number-limits` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 18 | Gateways & Routing | Mapping Gateways | `/admin/gateways/mapping` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 19 | Gateways & Routing | Mapping Gateway Detail | `/admin/gateways/mapping/{gatewayId}` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 20 | Gateways & Routing | Routing Gateways | `/admin/gateways/routing` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 21 | Gateways & Routing | Routing Gateway Detail | `/admin/gateways/routing/{gatewayId}` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 22 | Gateways & Routing | Online Gateways | `/admin/gateways/online` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 23 | Gateways & Routing | Gateway Network Quality | `/admin/gateways/network` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 24 | Gateways & Routing | Gateway Status Analytics | `/admin/gateways/status` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 25 | Gateways & Routing | Gateway Groups | `/admin/gateway-groups` | 09 — Admin Portal Foundation |
| Admin | 26 | Gateways & Routing | Registration Management | `/admin/registrations` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 27 | Gateways & Routing | Routing Analysis | `/admin/tools/routing-analysis` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 28 | Gateways & Routing | Network Test | `/admin/tools/network-test` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 29 | Gateways & Routing | Domain Management | `/admin/routing/domains` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 30 | Gateways & Routing | Prohibited Media IP | `/admin/routing/prohibited-media-ips` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 31 | Gateways & Routing | Softswitches | `/admin/softswitches` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 32 | Phones & Terminals | Phone Directory | `/admin/phones` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 33 | Phones & Terminals | Phone Detail | `/admin/phones/{phoneId}` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 34 | Phones & Terminals | Online Phones | `/admin/phones/online` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 35 | Live Calls & Diagnostics | Live Calls | `/admin/calls/live` | 08 — Realtime Calls, Gateway State & NOC |
| Admin | 36 | Live Calls & Diagnostics | Live Call Detail | `/admin/calls/live/{callId}` | 08 — Realtime Calls, Gateway State & NOC |
| Admin | 37 | Live Calls & Diagnostics | Call Analysis | `/admin/diagnostics/call-analysis` | 09 — Admin Portal Foundation |
| Admin | 38 | Live Calls & Diagnostics | Registration Analysis | `/admin/diagnostics/registration-analysis` | 09 — Admin Portal Foundation |
| Admin | 39 | CDR & Call Analytics | Recent CDR | `/admin/cdr/recent` | 09 — Admin Portal Foundation |
| Admin | 40 | CDR & Call Analytics | CDR Explorer | `/admin/cdr` | 09 — Admin Portal Foundation |
| Admin | 41 | CDR & Call Analytics | CDR Detail | `/admin/cdr/{cdrId}` | 09 — Admin Portal Foundation |
| Admin | 42 | CDR & Call Analytics | Failure Analytics | `/admin/analytics/failures` | 09 — Admin Portal Foundation |
| Admin | 43 | CDR & Call Analytics | Connect Analysis | `/admin/analytics/connect` | 09 — Admin Portal Foundation |
| Admin | 44 | CDR & Call Analytics | Interrupt Analysis | `/admin/analytics/interrupt` | 09 — Admin Portal Foundation |
| Admin | 45 | CDR & Call Analytics | Call Distribution | `/admin/analytics/distribution` | 09 — Admin Portal Foundation |
| Admin | 46 | CDR & Call Analytics | Historical Performance | `/admin/analytics/historical-performance` | 09 — Admin Portal Foundation |
| Admin | 47 | CDR & Call Analytics | Gateway Performance | `/admin/analytics/gateway-performance` | 09 — Admin Portal Foundation |
| Admin | 48 | Rates, Packages & Commercial Routing | Rate Groups | `/admin/rates/groups` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 49 | Rates, Packages & Commercial Routing | Rate Editor | `/admin/rates/groups/{groupId}` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 50 | Rates, Packages & Commercial Routing | Rate Import Jobs | `/admin/rates/imports` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 51 | Rates, Packages & Commercial Routing | Rate Lookup | `/admin/rates/lookup` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 52 | Rates, Packages & Commercial Routing | Package Groups | `/admin/packages` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 53 | Rates, Packages & Commercial Routing | Package Period Rates | `/admin/packages/{packageId}/period-rates` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 54 | Rates, Packages & Commercial Routing | Package Free Duration | `/admin/packages/{packageId}/free-duration` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 55 | Rates, Packages & Commercial Routing | Margin Monitor | `/admin/commercial/margins` | 09 — Admin Portal Foundation |
| Admin | 56 | Billing, Payments & Settlement | Payment Ledger | `/admin/payments` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Admin | 57 | Billing, Payments & Settlement | Manual Payment / Credit | `/admin/payments/new` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Admin | 58 | Billing, Payments & Settlement | Revenue Details | `/admin/billing/revenue` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Admin | 59 | Billing, Payments & Settlement | Gateway Bills | `/admin/billing/gateway` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Admin | 60 | Billing, Payments & Settlement | Phone Bills | `/admin/billing/phone` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Admin | 61 | Billing, Payments & Settlement | Account Balance Report | `/admin/billing/account-balance` | 11 — Accounts, Customers, Agents & User Management |
| Admin | 62 | Billing, Payments & Settlement | Clearing & Settlement | `/admin/settlement` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Admin | 63 | Reports | Report Center | `/admin/reports` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Admin | 64 | Reports | Gateway Analysis Reports | `/admin/reports/gateways` | 12 — Gateways, Phones, Routing & Network Tools |
| Admin | 65 | Reports | Agent Income Report | `/admin/reports/agent-income` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Admin | 66 | Reports | Scheduled Reports | `/admin/reports/schedules` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Admin | 67 | Number Management | Number Sections | `/admin/numbers/sections` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 68 | Number Management | Area Information | `/admin/numbers/areas` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 69 | Number Management | Number Transform | `/admin/numbers/transforms` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 70 | Number Management | Black / White List Groups | `/admin/numbers/lists` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 71 | Number Management | System White List | `/admin/numbers/system-whitelist` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 72 | Number Management | Dynamic Black List | `/admin/numbers/dynamic-blacklist` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Admin | 73 | Admin Users, Roles & Audit | Admin Users | `/admin/security/users` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Admin | 74 | Admin Users, Roles & Audit | Roles & Permissions | `/admin/security/roles` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Admin | 75 | Admin Users, Roles & Audit | Online Admin Users | `/admin/security/online-users` | 09 — Admin Portal Foundation |
| Admin | 76 | Admin Users, Roles & Audit | Portal Audit Log | `/admin/audit` | 09 — Admin Portal Foundation |
| Admin | 77 | Admin Users, Roles & Audit | VOS System Log | `/admin/system/vos-log` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 78 | System & Maintenance | System Parameters | `/admin/system/parameters` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 79 | System & Maintenance | System Information | `/admin/system/info` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 80 | System & Maintenance | Data Maintenance | `/admin/system/data-maintenance` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 81 | System & Maintenance | Performance Monitor | `/admin/system/performance` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 82 | System & Maintenance | Process Monitor | `/admin/system/processes` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 83 | System & Maintenance | Server Monitor | `/admin/system/servers` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 84 | System & Maintenance | Disaster Recovery | `/admin/system/disaster-recovery` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 85 | System & Maintenance | Work Calendar | `/admin/system/work-calendar` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 86 | API, Integrations & Automation | Portal API Clients | `/admin/integrations/api-clients` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 87 | API, Integrations & Automation | Webhook Endpoints | `/admin/integrations/webhooks` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Admin | 88 | API, Integrations & Automation | Webhook Delivery Log | `/admin/integrations/webhook-deliveries` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 89 | API, Integrations & Automation | VOS Web Access Control | `/admin/integrations/vos-access` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 90 | API, Integrations & Automation | VOS Web Service Equipment | `/admin/integrations/vos-equipment` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 91 | API, Integrations & Automation | Integration Health | `/admin/integrations/health` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 92 | Portal Operations | Support Tickets | `/admin/support/tickets` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Admin | 93 | Portal Operations | Notification Policies | `/admin/notifications/policies` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Admin | 94 | Portal Operations | Notification Log | `/admin/notifications/log` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Admin | 95 | Portal Operations | Payment Providers | `/admin/settings/payments` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Admin | 96 | Portal Operations | Portal Branding | `/admin/settings/branding` | 16 — System, Alarms, Observability, Security & DR |
| Admin | 97 | Portal Operations | Feature Flags | `/admin/settings/features` | 16 — System, Alarms, Observability, Security & DR |
| Client | 1 | Access & Account Security | Client Login | `/app/login` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Client | 2 | Access & Account Security | MFA Setup & Verify | `/app/settings/security/mfa` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Client | 3 | Access & Account Security | Sessions & Devices | `/app/settings/security/sessions` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Client | 4 | Access & Account Security | Profile & Organization | `/app/settings/profile` | 16 — System, Alarms, Observability, Security & DR |
| Client | 5 | Home & Overview | Client Dashboard | `/app` | 10 — Customer Portal Foundation |
| Client | 6 | Home & Overview | Service Status | `/app/status` | 08 — Realtime Calls, Gateway State & NOC |
| Client | 7 | Balance, Funds & Payments | Balance & Wallet | `/app/billing/balance` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Client | 8 | Balance, Funds & Payments | Add Funds | `/app/billing/add-funds` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Client | 9 | Balance, Funds & Payments | Payment History | `/app/billing/payments` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Client | 10 | Balance, Funds & Payments | Payment Detail / Receipt | `/app/billing/payments/{paymentId}` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Client | 11 | Balance, Funds & Payments | Statements & Billing Summary | `/app/billing/statements` | 14 — Billing, Payments, Wallet, Settlement & Statements |
| Client | 12 | CDR & Call History | CDR Explorer | `/app/cdr` | 07 — ClickHouse CDR Warehouse & Analytics |
| Client | 13 | CDR & Call History | CDR Detail | `/app/cdr/{cdrId}` | 07 — ClickHouse CDR Warehouse & Analytics |
| Client | 14 | CDR & Call History | Recent Calls | `/app/cdr/recent` | 07 — ClickHouse CDR Warehouse & Analytics |
| Client | 15 | CDR & Call History | CDR Export Jobs | `/app/cdr/exports` | 07 — ClickHouse CDR Warehouse & Analytics |
| Client | 16 | Live Calls & Traffic | Live Calls | `/app/calls/live` | 08 — Realtime Calls, Gateway State & NOC |
| Client | 17 | Live Calls & Traffic | Traffic Analytics | `/app/analytics/traffic` | 07 — ClickHouse CDR Warehouse & Analytics |
| Client | 18 | Live Calls & Traffic | Failure Analytics | `/app/analytics/failures` | 07 — ClickHouse CDR Warehouse & Analytics |
| Client | 19 | Live Calls & Traffic | Destination Analytics | `/app/analytics/destinations` | 07 — ClickHouse CDR Warehouse & Analytics |
| Client | 20 | Gateways & SIP | My Gateways | `/app/gateways` | 12 — Gateways, Phones, Routing & Network Tools |
| Client | 21 | Gateways & SIP | Gateway Detail | `/app/gateways/{gatewayId}` | 12 — Gateways, Phones, Routing & Network Tools |
| Client | 22 | Gateways & SIP | Gateway IP Management | `/app/gateways/{gatewayId}/ips` | 12 — Gateways, Phones, Routing & Network Tools |
| Client | 23 | Gateways & SIP | SIP Credentials | `/app/gateways/{gatewayId}/credentials` | 12 — Gateways, Phones, Routing & Network Tools |
| Client | 24 | Gateways & SIP | Gateway Network Quality | `/app/gateways/{gatewayId}/network` | 12 — Gateways, Phones, Routing & Network Tools |
| Client | 25 | Gateways & SIP | Gateway Call Statistics | `/app/gateways/{gatewayId}/statistics` | 12 — Gateways, Phones, Routing & Network Tools |
| Client | 26 | Rates & Pricing | My Rate Sheet | `/app/rates` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Client | 27 | Rates & Pricing | Rate Lookup | `/app/rates/lookup` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Client | 28 | Rates & Pricing | Rate Change History | `/app/rates/history` | 13 — Rates, Packages, Number Management & Commercial Controls |
| Client | 29 | Reports & Downloads | Reports Home | `/app/reports` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 30 | Reports & Downloads | Usage Report | `/app/reports/usage` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 31 | Reports & Downloads | Gateway Report | `/app/reports/gateways` | 12 — Gateways, Phones, Routing & Network Tools |
| Client | 32 | Reports & Downloads | Scheduled Reports | `/app/reports/schedules` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 33 | Reports & Downloads | Downloads | `/app/downloads` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 34 | Notifications | Notification Center | `/app/notifications` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 35 | Notifications | Alert Preferences | `/app/settings/notifications` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 36 | Developer API & Webhooks | API Overview | `/app/developers` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 37 | Developer API & Webhooks | API Keys | `/app/developers/api-keys` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 38 | Developer API & Webhooks | API Request Logs | `/app/developers/logs` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 39 | Developer API & Webhooks | Webhook Endpoints | `/app/developers/webhooks` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 40 | Developer API & Webhooks | Webhook Delivery Log | `/app/developers/webhook-deliveries` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 41 | Team & Permissions | Team Members | `/app/team` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Client | 42 | Team & Permissions | Client Roles | `/app/team/roles` | 03 — Identity, MFA, RBAC & Tenant Isolation |
| Client | 43 | Support | Support Tickets | `/app/support` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 44 | Support | New Support Ticket | `/app/support/new` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
| Client | 45 | Support | Ticket Detail | `/app/support/{ticketId}` | 15 — Reports, Exports, API, Webhooks, Notifications & Support |
