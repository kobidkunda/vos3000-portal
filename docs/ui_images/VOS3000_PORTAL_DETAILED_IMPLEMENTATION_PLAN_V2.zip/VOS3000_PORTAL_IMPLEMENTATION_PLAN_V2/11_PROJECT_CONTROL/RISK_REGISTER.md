# Risk Register

| Risk | Severity | Control |
|---|---|---|
| VOS GUI feature has no API | High | Capability matrix; hide unsupported writes |
| Direct VOS DB mutation | Critical | Prohibited by default |
| Duplicate CDR | Critical | verified dedupe + replay tests |
| CDR source retry insufficient | High | verify semantics + durable queue |
| Wrong ClickHouse key | High | benchmark real workload |
| Payment double credit | Critical | unique event + idempotency + reconciliation |
| Unknown VOS payment outcome | Critical | no blind retry |
| Cross-tenant leak | Critical | server scope + negative tests |
| Client DTO carrier leak | High | separate projections |
| VOS overload from polling | High | benchmark/adaptive interval |
| Huge export overload | High | async streaming worker |
| Webhook SSRF | High | egress validation/control |
| Rate bulk change financial damage | Critical | dry-run/diff/approval/golden tests |
| Backup unusable | Critical | restore drills |
| Multi-VOS ID collision | High | composite identity |
| Timezone/money precision mismatch | Critical | verified canonical rules |
