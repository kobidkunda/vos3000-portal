# MASTER_TODO.md

## Phase 00 — Source Audit & Capability Freeze

- [ ] Inventory supplied manual, admin/client specs, design reference and existing implementation plan.
- [ ] Identify installed VOS build, topology, timezone, currency and existing integrations.
- [ ] Create capability matrix for account, balance, payment, CDR, live calls, gateways, rates, users, alarms and system functions.
- [ ] Classify every required operation as VERIFIED_READ, VERIFIED_WRITE, PORTAL_ONLY, UNSUPPORTED or VERIFY_API.
- [ ] Capture sanitized real request/response fixtures for every verified interface.
- [ ] Measure current CDR/day, peak CDR/s, live-call concurrency and retention.
- [ ] Freeze source-of-truth terminology and IDs.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_00_*.md`.

## Phase 01 — Repository & Environment Foundation

- [ ] Create apps/web, apps/api, apps/cdr-ingest, apps/worker, apps/realtime.
- [ ] Create packages/config, db-postgres, db-clickhouse, redis, events, vos-adapter, auth, observability, shared.
- [ ] Enable TypeScript strict mode, linting, formatting and import boundaries.
- [ ] Create Docker Compose for PostgreSQL, PgBouncer, ClickHouse, Redis, Redpanda, MinIO, Prometheus, Grafana and Loki.
- [ ] Create typed env configuration and fail-fast validation.
- [ ] Create CI: install, lint, typecheck, unit, integration, migration check, container build.
- [ ] Deploy staging behind Nginx/TLS.
- [ ] Create /health/live, /health/ready and /version.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_01_*.md`.

## Phase 02 — PostgreSQL Business Data Foundation

- [ ] Create users, sessions, MFA, roles, permissions and memberships.
- [ ] Create tenants/customers and VOS mapping tables.
- [ ] Create VOS instances/accounts/gateways/phones/rate-group mapping.
- [ ] Create audit_log and immutable operation command tables.
- [ ] Create payment/deposit/ledger/reconciliation tables.
- [ ] Create API key, webhook, notification, report/export and support metadata tables.
- [ ] Add foreign keys, unique composite VOS identities and tenant indexes.
- [ ] Add migration policy and production-safe migration conventions.
- [ ] Create PgBouncer pool and connection budgets.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_02_*.md`.

## Phase 03 — Identity, MFA, RBAC & Tenant Isolation

- [ ] Implement login/logout/session rotation.
- [ ] Argon2id password hashing and password reset.
- [ ] TOTP MFA + recovery codes.
- [ ] Admin roles: Super Admin, NOC, Billing, Support, Commercial, Security, Read Only.
- [ ] Client roles: Owner, Billing, Technical/NOC, API Manager, Read Only.
- [ ] Implement service-layer authorize(action, resource, scope).
- [ ] Implement tenant scope in repository/service interfaces.
- [ ] Create IDOR/cross-tenant negative test suite.
- [ ] Create session/device page and revoke actions.
- [ ] Audit every auth/security mutation.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_03_*.md`.

## Phase 04 — VOS Adapter & Multi-Instance Integration

- [ ] Create vos_instances registry and protected credentials.
- [ ] Implement per-instance capability flags.
- [ ] Normalize VOS errors into typed retryable/non-retryable categories.
- [ ] Implement verified account, balance, CDR, gateway, live-call, payment-record and rate reads.
- [ ] Implement writes only when Phase 00 marks them VERIFIED_WRITE.
- [ ] Add timeout, circuit-breaker/degraded behavior and request correlation.
- [ ] Add readback verification after mutations.
- [ ] Build non-production contract tests for every enabled capability.
- [ ] Support identical upstream IDs across multiple VOS instances.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_04_*.md`.

## Phase 05 — Redpanda Event Backbone

- [ ] Create versioned event envelope.
- [ ] Create cdr.normalized.v1, gateway.state.v1, payment.*, webhook.delivery.v1, report.job.v1 topics.
- [ ] Choose partition keys based on tenant/VOS distribution and benchmark.
- [ ] Create DLQ topics and poison-event policy.
- [ ] Configure producer acknowledgements/retries.
- [ ] Create consumer group conventions.
- [ ] Add consumer lag metrics and alerts.
- [ ] Document retention based on measured traffic/recovery window.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_05_*.md`.

## Phase 06 — CDR Ingestion & Normalization

- [ ] Implement verified VOS push receiver or safe import/pull connector.
- [ ] Source authentication/IP allowlist.
- [ ] Normalize phone numbers as strings; preserve original values.
- [ ] Normalize timestamps to UTC while preserving source timezone metadata.
- [ ] Normalize durations and money precision from verified VOS samples.
- [ ] Map tenant, account, mapping gateway, routing gateway and VOS instance.
- [ ] Implement dedupe using verified serial uniqueness or deterministic fallback.
- [ ] Publish durable event before upstream acknowledgement where protocol supports.
- [ ] Batch ClickHouse writes via consumer.
- [ ] Create DLQ inspection and replay tooling.
- [ ] Add outage/restart/duplicate tests.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_06_*.md`.

## Phase 07 — ClickHouse CDR Warehouse & Analytics

- [ ] Create canonical cdr_events schema.
- [ ] Benchmark partitioning and ORDER BY using real query patterns.
- [ ] Create hourly/daily customer rollups.
- [ ] Create gateway, destination and failure aggregates.
- [ ] Store sums/counts for recomputable ASR/ACD/PDD ratios.
- [ ] Implement tenant/time query guardrails.
- [ ] Implement cursor pagination.
- [ ] Add query timeout/cancellation and concurrency budgets.
- [ ] Validate aggregates against raw CDR and VOS samples.
- [ ] Define retention/TTL only after business approval.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_07_*.md`.

## Phase 08 — Realtime Calls, Gateway State & NOC

- [ ] Implement Current Call collector per VOS instance.
- [ ] Implement Online Mapping/Routing Gateway collectors.
- [ ] Implement Gateway Network quality collector.
- [ ] Design Redis key namespaces and TTLs.
- [ ] Compute state diffs and publish gateway state changes.
- [ ] Implement authorized WebSocket/SSE snapshot + incremental stream.
- [ ] Handle reconnect with fresh snapshot.
- [ ] Mark stale/degraded data when source polling fails.
- [ ] Implement live-call disconnect only if verified and admin-authorized.
- [ ] Load-test expected live concurrency without overloading VOS.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_08_*.md`.

## Phase 09 — Admin Portal Foundation

- [ ] Admin shell, navigation, route guards and permission-aware menus.
- [ ] Global search/command palette foundation.
- [ ] Environment/integration-health indicators.
- [ ] Shared table/filter/export framework.
- [ ] Shared form/diff/confirm pattern for risky changes.
- [ ] Dashboard KPI framework using aggregates/live state.
- [ ] NOC wallboard foundation.
- [ ] Audit trail components.
- [ ] Loading, empty, error, forbidden and degraded states.
- [ ] Responsive and dark-mode NOC behavior.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_09_*.md`.

## Phase 10 — Customer Portal Foundation

- [ ] Client shell/navigation.
- [ ] Customer dashboard cards and freshness indicators.
- [ ] Tenant-safe table/filter/export components.
- [ ] Payment status component.
- [ ] Gateway status component.
- [ ] Rate lookup component.
- [ ] Support/ticket entry components.
- [ ] Developer API key/webhook components.
- [ ] Mobile responsive behavior.
- [ ] Client DTO redaction tests.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_10_*.md`.

## Phase 11 — Accounts, Customers, Agents & User Management

- [ ] Admin customer directory and create wizard.
- [ ] Map portal customer to one/multiple VOS accounts.
- [ ] Customer overview tabs and quick actions.
- [ ] Account settings, status, expiry, rate-group mapping and notes.
- [ ] Agent/subaccount tree.
- [ ] Authorization management.
- [ ] Number-section limitations.
- [ ] Customer team/subusers.
- [ ] Client profile/organization/security pages.
- [ ] Verified create/update/lock operations with readback.
- [ ] Full audit and UAT.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_11_*.md`.

## Phase 12 — Gateways, Phones, Routing & Network Tools

- [ ] Mapping gateway directory/detail.
- [ ] Routing gateway directory/detail.
- [ ] Gateway groups.
- [ ] Online gateway views.
- [ ] Network quality views.
- [ ] Gateway status analytics.
- [ ] Registration management.
- [ ] Phone directory/detail/online phone.
- [ ] Routing analysis.
- [ ] Network test.
- [ ] Domain/prohibited media/softswitch pages.
- [ ] Client My Gateways/details/network.
- [ ] Client IP management/credential rotation only when verified.
- [ ] Change preview/readback/rollback and audit.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_12_*.md`.

## Phase 13 — Rates, Packages, Number Management & Commercial Controls

- [ ] Rate group directory/editor.
- [ ] Rate import staging, validation, dry run and apply.
- [ ] Rate lookup and customer-safe rate sheet.
- [ ] Rate version/publication history.
- [ ] Package groups, period rates and free-duration.
- [ ] Customer package assignment.
- [ ] Margin monitor using verified charge/expense semantics.
- [ ] Number sections/areas/transforms.
- [ ] Black/white lists, system whitelist, dynamic blacklist.
- [ ] Golden routing test numbers before/after changes.
- [ ] Approval workflow for high-impact bulk changes.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_13_*.md`.

## Phase 14 — Billing, Payments, Wallet, Settlement & Statements

- [ ] Customer balance/wallet.
- [ ] Add-funds deposit creation.
- [ ] Provider webhook signature verification.
- [ ] Duplicate provider-event protection.
- [ ] Immutable ledger postings.
- [ ] VOS credit command with unknown-outcome state.
- [ ] Provider/ledger/VOS reconciliation.
- [ ] Admin manual payment/credit/make-zero only if verified.
- [ ] Payment history/detail/receipt.
- [ ] Revenue/gateway/phone bills.
- [ ] Account balance reports.
- [ ] Clearing/settlement views.
- [ ] Statements and exact currency handling.
- [ ] Daily reconciliation dashboard and runbook.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_14_*.md`.

## Phase 15 — Reports, Exports, API, Webhooks, Notifications & Support

- [ ] Async CDR/report jobs.
- [ ] Stream CSV.gz/Parquet output to object storage.
- [ ] XLSX row/size policy.
- [ ] Scheduled reports with timezone.
- [ ] Public /api/v1 and OpenAPI.
- [ ] API key scopes, IP restrictions and rate limits.
- [ ] API request logs with redaction.
- [ ] Signed HMAC webhooks and replay protection.
- [ ] Webhook retries/DLQ/SSRF controls.
- [ ] Notification center and preferences.
- [ ] Admin notification policies/log.
- [ ] Support ticket creation/detail/admin queue.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_15_*.md`.

## Phase 16 — System, Alarms, Observability, Security & DR

- [ ] Alarm center and historical alarms.
- [ ] VOS system log/parameter/info/maintenance pages where verified.
- [ ] Integration/system health pages.
- [ ] Prometheus metrics and Grafana dashboards.
- [ ] Loki structured logs and request/event correlation.
- [ ] Define SLOs for API, CDR lag, live freshness and payments.
- [ ] Alert runbooks for CDR, DB, queue, provider and VOS failures.
- [ ] Security hardening: network isolation, CSRF, CSP, SSRF, secret rotation.
- [ ] PostgreSQL/ClickHouse/object-storage backup strategy.
- [ ] Perform clean restore drills.
- [ ] Document HA expansion and remaining SPOFs.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_16_*.md`.

## Phase 17 — Migration, Load Test, UAT, Cutover & Hypercare

- [ ] Map existing customers/accounts/gateways without duplicating VOS objects.
- [ ] Backfill historical CDR if required with checkpoints.
- [ ] Reconcile counts/minutes/charges by day/account/gateway.
- [ ] Load-test measured peak, 2x and 5x bursts.
- [ ] Test ClickHouse outage and Redpanda catch-up.
- [ ] Test duplicate CDR replay.
- [ ] Test concurrent UI/CDR/export workloads.
- [ ] Run admin/client role-based UAT.
- [ ] Run payment idempotency/reconciliation UAT.
- [ ] Run security and cross-tenant final tests.
- [ ] Take production backup/restore checkpoint.
- [ ] Staged rollout: read-only first, then money/config writes.
- [ ] Prepare rollback plan and hypercare dashboards.
- [ ] Do not enable any unverified VOS write.
- [ ] Complete phase exit gate in `03_PHASES/PHASE_17_*.md`.
