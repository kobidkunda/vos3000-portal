# Load Test Plan

Measure real production baseline first.

Scenarios:
1. steady CDR at measured peak
2. 2x peak sustained
3. 5x short burst
4. ClickHouse unavailable while ingest continues
5. consumer restart and catch-up
6. duplicate replay
7. 10M/100M+ row historical queries
8. concurrent dashboards + CDR pagination
9. live stream connections
10. 1M/10M-row export jobs where product permits

Pass:
- zero lost accepted logical CDR
- zero duplicate aggregate contribution
- lag recovers in approved time
- p95 interactive query under approved SLO
- bounded worker memory
- no VOS overload from realtime polling
