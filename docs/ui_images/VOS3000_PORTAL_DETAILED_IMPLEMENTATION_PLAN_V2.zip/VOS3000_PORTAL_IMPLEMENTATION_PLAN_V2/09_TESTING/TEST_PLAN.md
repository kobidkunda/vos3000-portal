# Test Plan

## Required per feature
- unit
- integration
- API validation
- authorization
- tenant isolation
- failure/retry
- UI state
- accessibility

## VOS-backed
- contract test against non-production build
- before/after readback for writes
- timeout and unknown outcome

## CDR
- duplicate
- replay
- out-of-order
- malformed/DLQ
- ClickHouse outage
- Redpanda restart
- target peak, 2x, 5x

## Payments
- duplicate provider webhook
- provider success + VOS timeout
- VOS success + lost response
- concurrent deposits
- exact rounding
- reconciliation

## Security
- IDOR
- privilege escalation
- CSRF
- webhook SSRF
- secret redaction
- export ownership
