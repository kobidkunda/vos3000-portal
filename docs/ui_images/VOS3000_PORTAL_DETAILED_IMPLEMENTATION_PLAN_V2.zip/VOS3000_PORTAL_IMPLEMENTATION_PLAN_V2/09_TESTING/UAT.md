# UAT

Admin:
- auth/MFA/RBAC
- dashboard/NOC
- customer/account
- balance/payment
- gateways/network
- live calls
- CDR/detail/export
- rates/routing
- alarms/reports/audit

Client:
- auth/security
- dashboard
- balance/add funds
- CDR/detail/export
- live calls
- gateways/network
- rates/lookup
- reports
- API/webhook
- support/team

Negative:
- Customer A cannot access Customer B by changing URL, filter, cursor, API key, export ID or gateway ID.
