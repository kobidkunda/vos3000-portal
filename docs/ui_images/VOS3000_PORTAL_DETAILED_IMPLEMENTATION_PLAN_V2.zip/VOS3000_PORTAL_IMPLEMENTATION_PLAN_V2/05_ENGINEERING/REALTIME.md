# Realtime

Sources:
- Current Call
- Online Mapping Gateway
- Online Routing Gateway
- Gateway Network

Redis stores latest normalized snapshots with TTL.

UI stream:
1. authorize
2. send fresh snapshot
3. send incremental changes
4. heartbeat
5. on source failure, mark stale/degraded
6. reconnect always refreshes snapshot

Never present old Redis data as current without freshness.
