# CDR Pipeline

```text
VOS -> CDR Receiver -> validate/normalize -> Redpanda -> ClickHouse Writer -> ClickHouse
                                      |                         |
                                      +--> DLQ                  +--> rollups
```

## Dedupe
Preferred only after verification:
`(vos_instance_id, source_serial_number)`

Fallback: deterministic fingerprint of immutable call identity fields.

## Normalization
- numbers remain strings
- UTC canonical timestamps
- source timezone retained
- exact Decimal money
- source Call-IDs and serial retained
- mapping/routing gateway identity includes VOS instance

## Insert
Batch by count/time. Never one ClickHouse insert per CDR.

## Replay
Consumers are idempotent/effectively-once.
Offsets commit after durable ClickHouse insert policy.
