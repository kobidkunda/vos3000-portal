# Payments

State:
`CREATED -> PENDING_PROVIDER -> PROVIDER_CONFIRMED -> CREDITING_VOS -> COMPLETED`

Failure:
- PROVIDER_FAILED
- VOS_CREDIT_FAILED
- OUTCOME_UNKNOWN
- REQUIRES_RECONCILIATION
- REFUNDED/REVERSED where applicable

Rules:
- provider webhook signature verification
- unique provider event
- immutable ledger
- exact money
- idempotency key
- VOS command persisted before send
- no blind retry after unknown VOS outcome
- scheduled reconciliation
