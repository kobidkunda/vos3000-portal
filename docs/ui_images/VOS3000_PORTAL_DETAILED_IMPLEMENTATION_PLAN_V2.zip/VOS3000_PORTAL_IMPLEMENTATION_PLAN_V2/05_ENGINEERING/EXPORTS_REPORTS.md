# Exports & Reports

API only creates job; worker does heavy work.

Flow:
`request -> PG job -> Redpanda -> worker -> ClickHouse stream -> object storage -> authorized download`

Formats:
- CSV.gz: default large raw export
- Parquet: huge analytical export
- XLSX: bounded row/size policy
- PDF: summarized statements only

Never create multi-million-row exports in API memory.
