# VOS Adapter Implementation

## Contract
All VOS-specific reads/writes live in one package/module.

Capability flags:
- account.read/create/update/lock
- balance.read
- payment.read/credit
- cdr.read/recent
- current_calls.read/disconnect
- mapping_gateway.read/create/update
- routing_gateway.read/update
- gateway.online.read
- gateway.network.read
- phone.read/update
- rates.read/write
- routing.analysis
- alarms.read
- system.log.read
- system.parameters.read/write

Unknown = disabled.

## Write algorithm
1. authenticate portal actor
2. authorize action
3. validate resource scope
4. check per-VOS capability
5. create command/audit record
6. call VOS with timeout
7. classify result
8. read back actual state where possible
9. mark SUCCEEDED / FAILED / OUTCOME_UNKNOWN
10. reconcile unknown outcome before retry

Never blindly retry a mutation with unknown outcome.
