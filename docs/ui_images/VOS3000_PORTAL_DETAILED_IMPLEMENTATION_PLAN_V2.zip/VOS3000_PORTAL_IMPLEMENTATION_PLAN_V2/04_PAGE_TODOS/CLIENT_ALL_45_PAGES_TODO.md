# Client Portal — Complete Page Implementation TODOs

Total pages: **45**.

Every page below must be implemented or explicitly marked deferred with reason. This is the anti-skip checklist.

## 001. Client Login

- **Group:** Access & Account Security
- **Route:** `/app/login`
- **Primary phase:** Phase 03
- **Purpose:** Secure customer sign-in.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Email/username and password
- [ ] MFA challenge when enabled
- [ ] Remember device subject to policy
- [ ] Forgot password
- [ ] Clear account-suspended/expired states without exposing sensitive backend details

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/auth/login`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 002. MFA Setup & Verify

- **Group:** Access & Account Security
- **Route:** `/app/settings/security/mfa`
- **Primary phase:** Phase 03
- **Purpose:** Protect customer accounts with second factor.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Enable/disable MFA after re-authentication
- [ ] TOTP QR/setup key
- [ ] Recovery codes
- [ ] Verify before activation
- [ ] Regenerate recovery codes
- [ ] Recent security events

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/me/mfa`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 003. Sessions & Devices

- **Group:** Access & Account Security
- **Route:** `/app/settings/security/sessions`
- **Primary phase:** Phase 03
- **Purpose:** Customer session management.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Current device
- [ ] other sessions with IP/browser/time
- [ ] revoke individual
- [ ] revoke all others
- [ ] security notification on new login

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/me/sessions`.
- [ ] Implement/verify `DELETE /api/v1/me/sessions/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 004. Profile & Organization

- **Group:** Access & Account Security
- **Route:** `/app/settings/profile`
- **Primary phase:** Phase 16
- **Purpose:** Manage customer-facing profile data.
- **Source basis:** ** [HYBRID]

### Feature TODO
- [ ] Organization name
- [ ] billing/contact emails
- [ ] phone
- [ ] timezone
- [ ] default report timezone
- [ ] notification preferences
- [ ] VOS account ID read-only where appropriate

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/me/profile`.
- [ ] Implement/verify `PATCH /api/v1/me/profile`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 005. Client Dashboard

- **Group:** Home & Overview
- **Route:** `/app`
- **Primary phase:** Phase 10
- **Purpose:** At-a-glance balance, traffic and service status.
- **Source basis:** ** VOS documents account balance/today consumption, current calls and online gateway metrics. Dashboard composition is [HYBRID].

### Feature TODO
- [ ] Balance
- [ ] credit/overdraft if customer is allowed to see it
- [ ] today spend
- [ ] month-to-date spend
- [ ] active calls
- [ ] channel usage
- [ ] current CPS vs limit
- [ ] ASR
- [ ] ACD
- [ ] PDD
- [ ] gateway online/offline count
- [ ] recent payment
- [ ] 24h calls/minutes/spend charts
- [ ] low balance/expiry/gateway issue banners
- [ ] quick links: Add Funds, Live Calls, CDR, Gateways, Rate Lookup

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/dashboard/summary`.
- [ ] Implement/verify `GET /api/v1/dashboard/timeseries`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 006. Service Status

- **Group:** Home & Overview
- **Route:** `/app/status`
- **Primary phase:** Phase 08
- **Purpose:** Customer-specific service health.
- **Source basis:** ** Uses documented VOS gateway online/network data plus portal incident context. [HYBRID]

### Feature TODO
- [ ] My gateways
- [ ] online/offline/degraded
- [ ] registered IP
- [ ] last update
- [ ] network quality
- [ ] packet loss
- [ ] latency
- [ ] active incidents affecting this customer
- [ ] refresh timestamp

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/status`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 007. Balance & Wallet

- **Group:** Balance, Funds & Payments
- **Route:** `/app/billing/balance`
- **Primary phase:** Phase 14
- **Purpose:** Primary account-balance page.
- **Source basis:** ** VOS account balance/today consumption are documented. Trend is [HYBRID].

### Feature TODO
- [ ] Current VOS balance
- [ ] Available credit if applicable
- [ ] today consumption
- [ ] month spend
- [ ] low-balance threshold
- [ ] last payments
- [ ] Add Funds button
- [ ] balance trend from portal snapshots

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/balance`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 008. Add Funds

- **Group:** Balance, Funds & Payments
- **Route:** `/app/billing/add-funds`
- **Primary phase:** Phase 14
- **Purpose:** Self-service payment flow.
- **Source basis:** ** Online payment provider is [PORTAL]; confirmed funds can be translated into VOS Payment/Credit via adapter [VERIFY-API].

### Feature TODO
- [ ] Preset and custom amount
- [ ] Currency
- [ ] Payment method selection
- [ ] Minimum/maximum validation
- [ ] Fees/expected credit disclosure
- [ ] Redirect/embedded provider flow
- [ ] Pending/success/failed states
- [ ] Idempotent payment creation
- [ ] Never credit VOS until payment is independently verified by backend webhook

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/deposits`.
- [ ] Implement/verify `GET /api/v1/deposits/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 009. Payment History

- **Group:** Balance, Funds & Payments
- **Route:** `/app/billing/payments`
- **Primary phase:** Phase 14
- **Purpose:** Customer-visible ledger.
- **Source basis:** ** VOS Payment Record documents account, payment amount, balance after payment, type, time, mode and serial. [HYBRID]

### Feature TODO
- [ ] Date
- [ ] amount
- [ ] type
- [ ] method
- [ ] status
- [ ] balance after payment when available
- [ ] reference/serial
- [ ] receipt
- [ ] filters and export
- [ ] exclude internal-only operator notes

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/payments`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 010. Payment Detail / Receipt

- **Group:** Balance, Funds & Payments
- **Route:** `/app/billing/payments/{paymentId}`
- **Primary phase:** Phase 14
- **Purpose:** Single payment record and receipt.
- **Source basis:** ** [HYBRID]

### Feature TODO
- [ ] Processor reference
- [ ] VOS/portal transaction reference
- [ ] amount/currency
- [ ] fees
- [ ] credited amount
- [ ] created/completed time
- [ ] status timeline
- [ ] balance after credit
- [ ] download receipt
- [ ] support link

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/payments/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 011. Statements & Billing Summary

- **Group:** Balance, Funds & Payments
- **Route:** `/app/billing/statements`
- **Primary phase:** Phase 14
- **Purpose:** Periodic usage and financial summary.
- **Source basis:** ** VOS provides account balance/revenue/bill queries. Formal statement presentation is [HYBRID].

### Feature TODO
- [ ] Opening balance
- [ ] payments/credits
- [ ] call charges
- [ ] package/rent items if applicable
- [ ] closing balance
- [ ] minutes/calls
- [ ] date range
- [ ] download CSV/PDF where implemented

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/billing/statements`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 012. CDR Explorer

- **Group:** CDR & Call History
- **Route:** `/app/cdr`
- **Primary phase:** Phase 07
- **Purpose:** Customer-scoped call history.
- **Source basis:** ** VOS CDR documents the underlying fields. Tenant scoping and export UX are [HYBRID].

### Feature TODO
- [ ] Default recent date range
- [ ] Filters: begin/end date, caller, callee, gateway, call status/termination reason, duration, destination/area, Call-ID
- [ ] Columns: begin/end, caller/callee, duration, charged duration, customer charge, mapping gateway, destination, termination reason
- [ ] Customer cannot access other accounts even by manipulating query parameters
- [ ] Saved filters
- [ ] CSV/XLSX export
- [ ] Server-side pagination

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/cdr`.
- [ ] Implement/verify `POST /api/v1/cdr/exports`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 013. CDR Detail

- **Group:** CDR & Call History
- **Route:** `/app/cdr/{cdrId}`
- **Primary phase:** Phase 07
- **Purpose:** Explain one call without exposing sensitive carrier internals.
- **Source basis:** ** VOS CDR contains richer carrier-side information; client response must be projection/redaction. [HYBRID]

### Feature TODO
- [ ] Begin/end time
- [ ] caller/callee
- [ ] actual and charged duration
- [ ] customer call charge
- [ ] call type/destination/area
- [ ] customer mapping gateway
- [ ] caller IP if customer is authorized to see it
- [ ] termination reason/hangup side
- [ ] PDD/connection delay
- [ ] customer-side Call-ID/serial as appropriate
- [ ] Report Problem button
- [ ] Do not reveal carrier cost, routing gateway, other-customer data, private softswitch internals unless explicitly allowed

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/cdr/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 014. Recent Calls

- **Group:** CDR & Call History
- **Route:** `/app/cdr/recent`
- **Primary phase:** Phase 07
- **Purpose:** Fast view of recent records.
- **Source basis:** ** VOS Recent CDR is documented. [VOS]/[HYBRID]

### Feature TODO
- [ ] Most recent calls
- [ ] answer/failure badge
- [ ] caller/callee
- [ ] duration
- [ ] charge
- [ ] gateway
- [ ] termination reason
- [ ] open detail

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/cdr/recent`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 015. CDR Export Jobs

- **Group:** CDR & Call History
- **Route:** `/app/cdr/exports`
- **Primary phase:** Phase 07
- **Purpose:** Handle large exports safely.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Requested range/filter
- [ ] status queued/running/ready/expired/failed
- [ ] row count
- [ ] created/expiry time
- [ ] download when ready
- [ ] cancel queued job
- [ ] rate limit export creation

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/cdr/exports`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 016. Live Calls

- **Group:** Live Calls & Traffic
- **Route:** `/app/calls/live`
- **Primary phase:** Phase 08
- **Purpose:** Customer-only real-time active sessions.
- **Source basis:** ** VOS Current Call provides the underlying live-call fields. Customer projection is [HYBRID].

### Feature TODO
- [ ] Caller/callee
- [ ] customer gateway
- [ ] connect time
- [ ] duration
- [ ] PDD
- [ ] codec where allowed
- [ ] active call count vs channels
- [ ] search/filter
- [ ] auto-refresh/WebSocket status
- [ ] no disconnect button by default
- [ ] carrier routing gateway and sensitive media details redacted

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/calls/live`.
- [ ] Implement/verify `GET /api/v1/calls/live/stream`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 017. Traffic Analytics

- **Group:** Live Calls & Traffic
- **Route:** `/app/analytics/traffic`
- **Primary phase:** Phase 07
- **Purpose:** Understand call volume and minutes.
- **Source basis:** ** VOS has CDR Analysis and gateway performance; customer analytics are [HYBRID].

### Feature TODO
- [ ] Calls
- [ ] answered
- [ ] failed
- [ ] minutes
- [ ] spend
- [ ] ASR
- [ ] ACD
- [ ] PDD
- [ ] hour/day granularity
- [ ] destination breakdown
- [ ] gateway breakdown
- [ ] compare previous period
- [ ] export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/analytics/traffic`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 018. Failure Analytics

- **Group:** Live Calls & Traffic
- **Route:** `/app/analytics/failures`
- **Primary phase:** Phase 07
- **Purpose:** Customer-facing call failure intelligence.
- **Source basis:** ** VOS CDR termination reason and gateway outcome data support this. [HYBRID]

### Feature TODO
- [ ] Top termination reasons
- [ ] failure-rate trend
- [ ] failure by destination
- [ ] failure by customer gateway
- [ ] human-readable explanation
- [ ] drill to affected CDRs
- [ ] do not expose other carrier/customer details

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/analytics/failures`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 019. Destination Analytics

- **Group:** Live Calls & Traffic
- **Route:** `/app/analytics/destinations`
- **Primary phase:** Phase 07
- **Purpose:** Traffic/spend/quality by destination.
- **Source basis:** ** Area prefix/name and CDR data are documented in VOS; aggregation is [HYBRID].

### Feature TODO
- [ ] Country/area/prefix
- [ ] calls
- [ ] minutes
- [ ] spend
- [ ] ASR
- [ ] ACD
- [ ] PDD
- [ ] trend
- [ ] rate lookup shortcut

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/analytics/destinations`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 020. My Gateways

- **Group:** Gateways & SIP
- **Route:** `/app/gateways`
- **Primary phase:** Phase 12
- **Purpose:** Customer-owned gateway inventory.
- **Source basis:** ** VOS mapping/online mapping gateway metrics are documented. [VOS]/[HYBRID]

### Feature TODO
- [ ] Gateway name
- [ ] configured/registered IP
- [ ] online status
- [ ] active calls vs line limit
- [ ] CPS
- [ ] ASR
- [ ] ACD
- [ ] last registration/update
- [ ] network quality badge
- [ ] open details
- [ ] Add Gateway request/action if enabled

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/gateways`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 021. Gateway Detail

- **Group:** Gateways & SIP
- **Route:** `/app/gateways/{gatewayId}`
- **Primary phase:** Phase 12
- **Purpose:** Single gateway configuration and health.
- **Source basis:** ** Based on VOS Mapping Gateway and Online Mapping Gateway. [HYBRID]

### Feature TODO
- [ ] Gateway identity
- [ ] account
- [ ] static/dynamic mode
- [ ] configured IP(s)
- [ ] registered IP
- [ ] signaling port if exposed
- [ ] line limit
- [ ] current calls
- [ ] CPS
- [ ] ASR/ACD
- [ ] registration/update time
- [ ] network latency/loss
- [ ] softswitch host details only if safe to expose
- [ ] CDR and live-call shortcuts
- [ ] configuration actions governed by customer permission

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/gateways/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 022. Gateway IP Management

- **Group:** Gateways & SIP
- **Route:** `/app/gateways/{gatewayId}/ips`
- **Primary phase:** Phase 12
- **Purpose:** Self-service customer IP changes with strong controls.
- **Source basis:** ** VOS mapping gateways are IP-address based and can expose registered IP; self-service workflow is [HYBRID]/[VERIFY-API].

### Feature TODO
- [ ] Current primary/backup IPs
- [ ] Add/replace/remove subject to plan
- [ ] IPv4/IPv6/CIDR validation based on VOS capability
- [ ] Require MFA/re-authentication
- [ ] Optional email approval/admin review
- [ ] Show impact warning before changing active gateway
- [ ] Audit old/new IP
- [ ] Connectivity status after change

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/gateways/{id}/ips`.
- [ ] Implement/verify `PUT /api/v1/gateways/{id}/ips`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 023. SIP Credentials

- **Group:** Gateways & SIP
- **Route:** `/app/gateways/{gatewayId}/credentials`
- **Primary phase:** Phase 12
- **Purpose:** Expose connection information without leaking reusable secrets.
- **Source basis:** ** VOS documents configuration/authentication credentials for gateway/phone objects; secure portal handling is [HYBRID]/[VERIFY-API].

### Feature TODO
- [ ] SIP host/address
- [ ] port
- [ ] protocol
- [ ] gateway/auth username if applicable
- [ ] password never re-displayed after creation
- [ ] Reset/rotate password action
- [ ] copy non-secret fields
- [ ] rotation confirmation and audit

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/gateways/{id}/credentials`.
- [ ] Implement/verify `POST /api/v1/gateways/{id}/credentials/rotate`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 024. Gateway Network Quality

- **Group:** Gateways & SIP
- **Route:** `/app/gateways/{gatewayId}/network`
- **Primary phase:** Phase 12
- **Purpose:** Network health for the customer's gateway.
- **Source basis:** ** VOS Mapping Gateway Network documents remote IP, network quality, packet loss and delay. History is [HYBRID].

### Feature TODO
- [ ] Remote IP
- [ ] current network quality
- [ ] packet loss
- [ ] network delay
- [ ] 24h/7d historical portal chart
- [ ] degraded thresholds
- [ ] support ticket shortcut

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/gateways/{id}/network`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 025. Gateway Call Statistics

- **Group:** Gateways & SIP
- **Route:** `/app/gateways/{gatewayId}/statistics`
- **Primary phase:** Phase 12
- **Purpose:** Call outcome stats for one customer gateway.
- **Source basis:** ** VOS Gateway Status documents these outcome fields. Customer-safe projection is [HYBRID].

### Feature TODO
- [ ] Total calls
- [ ] success
- [ ] callee rejected
- [ ] trunk/network errors where appropriate
- [ ] caller abandon
- [ ] average talk duration
- [ ] total call time
- [ ] time range
- [ ] drill to CDR

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/gateways/{id}/statistics`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 026. My Rate Sheet

- **Group:** Rates & Pricing
- **Route:** `/app/rates`
- **Primary phase:** Phase 13
- **Purpose:** Customer's assigned sell rates.
- **Source basis:** ** VOS Rate Management provides prefix, area, type, billing rate/cycle and rate/minute. Presentation/versioning is [HYBRID].

### Feature TODO
- [ ] Search by country/destination/prefix
- [ ] Prefix
- [ ] area/destination
- [ ] rate type
- [ ] rate/minute
- [ ] billing cycle where customer-facing
- [ ] effective date supplied by portal rate-versioning
- [ ] download CSV/XLSX
- [ ] never expose carrier cost/private admin margins

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/rates`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 027. Rate Lookup

- **Group:** Rates & Pricing
- **Route:** `/app/rates/lookup`
- **Primary phase:** Phase 13
- **Purpose:** Instant price lookup for a called number.
- **Source basis:** ** VOS uses longest-prefix matching; customer lookup is [HYBRID].

### Feature TODO
- [ ] Number input
- [ ] normalized number
- [ ] matched prefix
- [ ] destination
- [ ] rate type
- [ ] customer rate/minute
- [ ] billing increment/cycle
- [ ] clear no-rate result
- [ ] copy result

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/rates/lookup?number=...`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 028. Rate Change History

- **Group:** Rates & Pricing
- **Route:** `/app/rates/history`
- **Primary phase:** Phase 13
- **Purpose:** Transparency for customer rate changes.
- **Source basis:** ** Rate history/effective publishing workflow is a [PORTAL] extension unless a supported VOS mechanism is verified.

### Feature TODO
- [ ] Destination/prefix
- [ ] old rate
- [ ] new rate
- [ ] effective date
- [ ] published date
- [ ] filter upcoming/past
- [ ] download change file

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/rates/history`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 029. Reports Home

- **Group:** Reports & Downloads
- **Route:** `/app/reports`
- **Primary phase:** Phase 15
- **Purpose:** Customer report catalog.
- **Source basis:** ** [HYBRID]

### Feature TODO
- [ ] Traffic summary
- [ ] billing/usage
- [ ] destination
- [ ] gateway quality
- [ ] failure summary
- [ ] saved reports
- [ ] recent exports

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/reports`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 030. Usage Report

- **Group:** Reports & Downloads
- **Route:** `/app/reports/usage`
- **Primary phase:** Phase 15
- **Purpose:** Calls, minutes and spend report.
- **Source basis:** ** [HYBRID]

### Feature TODO
- [ ] Date range
- [ ] group by day/hour/destination/gateway
- [ ] calls
- [ ] answered
- [ ] minutes
- [ ] charges
- [ ] ASR/ACD where applicable
- [ ] export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/reports/usage`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 031. Gateway Report

- **Group:** Reports & Downloads
- **Route:** `/app/reports/gateways`
- **Primary phase:** Phase 12
- **Purpose:** Customer gateway performance report.
- **Source basis:** ** VOS has gateway reports/performance; customer projection is [HYBRID].

### Feature TODO
- [ ] Gateway
- [ ] calls
- [ ] minutes
- [ ] ASR
- [ ] ACD
- [ ] PDD
- [ ] failure rate
- [ ] network delay/loss if available
- [ ] export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/reports/gateways`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 032. Scheduled Reports

- **Group:** Reports & Downloads
- **Route:** `/app/reports/schedules`
- **Primary phase:** Phase 15
- **Purpose:** Automatic report delivery.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Choose report
- [ ] saved filters
- [ ] daily/weekly/monthly
- [ ] timezone
- [ ] recipient emails restricted to organization policy
- [ ] CSV/XLSX/PDF where supported
- [ ] pause/resume
- [ ] last/next run

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/report-schedules`.
- [ ] Implement/verify `POST /api/v1/report-schedules`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 033. Downloads

- **Group:** Reports & Downloads
- **Route:** `/app/downloads`
- **Primary phase:** Phase 15
- **Purpose:** Centralized generated files.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] CDR exports
- [ ] rate sheets
- [ ] statements
- [ ] reports
- [ ] status ready/expired
- [ ] size/row count
- [ ] expiry and delete

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/downloads`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 034. Notification Center

- **Group:** Notifications
- **Route:** `/app/notifications`
- **Primary phase:** Phase 15
- **Purpose:** In-app service and commercial alerts.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Low balance
- [ ] payment result
- [ ] gateway online/offline
- [ ] ASR/failure degradation
- [ ] rate change
- [ ] account expiry
- [ ] security events
- [ ] read/unread
- [ ] filter by type
- [ ] deep links

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/notifications`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 035. Alert Preferences

- **Group:** Notifications
- **Route:** `/app/settings/notifications`
- **Primary phase:** Phase 15
- **Purpose:** Customer-controlled notification channels and thresholds.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Low-balance amount
- [ ] gateway state alerts
- [ ] rate changes
- [ ] payment alerts
- [ ] security alerts always-on where required
- [ ] email/webhook/other channel toggles
- [ ] quiet-hours policy only for noncritical alerts

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/me/notification-preferences`.
- [ ] Implement/verify `PUT /api/v1/me/notification-preferences`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 036. API Overview

- **Group:** Developer API & Webhooks
- **Route:** `/app/developers`
- **Primary phase:** Phase 15
- **Purpose:** Customer entry point for programmatic access.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Base URL
- [ ] authentication model
- [ ] scopes summary
- [ ] rate limits
- [ ] quick-start snippets
- [ ] links to CDR/balance/gateway/rates endpoints
- [ ] sandbox/test notes if provided

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/developer/overview`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 037. API Keys

- **Group:** Developer API & Webhooks
- **Route:** `/app/developers/api-keys`
- **Primary phase:** Phase 15
- **Purpose:** Create and manage customer API credentials.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Key name
- [ ] key ID
- [ ] secret shown once
- [ ] scopes
- [ ] IP allowlist
- [ ] expiry
- [ ] last used
- [ ] rotate/revoke
- [ ] max active keys per account

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/api-keys`.
- [ ] Implement/verify `POST /api/v1/api-keys`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 038. API Request Logs

- **Group:** Developer API & Webhooks
- **Route:** `/app/developers/logs`
- **Primary phase:** Phase 15
- **Purpose:** Customer-visible API diagnostics.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Timestamp
- [ ] method/path
- [ ] status
- [ ] latency
- [ ] request ID
- [ ] key name
- [ ] IP
- [ ] filter/export
- [ ] redact secrets and sensitive payload data

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/developer/request-logs`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 039. Webhook Endpoints

- **Group:** Developer API & Webhooks
- **Route:** `/app/developers/webhooks`
- **Primary phase:** Phase 15
- **Purpose:** Customer event subscriptions.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Endpoint URL
- [ ] events such as call.completed, gateway.online/offline, balance.low, payment.completed, rate.changed
- [ ] signing secret shown once/rotatable
- [ ] enable/disable
- [ ] test delivery

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/webhooks`.
- [ ] Implement/verify `POST /api/v1/webhooks`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 040. Webhook Delivery Log

- **Group:** Developer API & Webhooks
- **Route:** `/app/developers/webhook-deliveries`
- **Primary phase:** Phase 15
- **Purpose:** Debug webhook failures.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Event
- [ ] endpoint
- [ ] attempt
- [ ] HTTP status
- [ ] latency
- [ ] next retry
- [ ] payload preview with redaction
- [ ] manual retry if allowed

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/webhook-deliveries`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 041. Team Members

- **Group:** Team & Permissions
- **Route:** `/app/team`
- **Primary phase:** Phase 03
- **Purpose:** Organization-level portal users.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Name/email
- [ ] role
- [ ] status
- [ ] last login
- [ ] MFA state
- [ ] invite member
- [ ] resend/revoke invite
- [ ] disable/remove member

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/team`.
- [ ] Implement/verify `POST /api/v1/team/invitations`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 042. Client Roles

- **Group:** Team & Permissions
- **Route:** `/app/team/roles`
- **Primary phase:** Phase 03
- **Purpose:** Customer-admin-managed RBAC.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Owner, Billing, Technical/NOC, Read Only, API Manager
- [ ] Permissions: view CDR, view rates, view balance, add funds, manage gateway IP, view live calls, manage API, download reports, manage team
- [ ] Custom roles optionally later

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/team/roles`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 043. Support Tickets

- **Group:** Support
- **Route:** `/app/support`
- **Primary phase:** Phase 15
- **Purpose:** Customer support history and new ticket entry.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Open/pending/resolved statuses
- [ ] category Billing/Routing/Quality/Technical/Rate/Payment/Other
- [ ] priority
- [ ] last update
- [ ] search/filter
- [ ] new ticket

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/support/tickets`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 044. New Support Ticket

- **Group:** Support
- **Route:** `/app/support/new`
- **Primary phase:** Phase 15
- **Purpose:** Create context-rich support request.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Subject
- [ ] category
- [ ] description
- [ ] optional gateway
- [ ] optional CDR/call ID
- [ ] attachment
- [ ] auto-attach safe diagnostics after user consent
- [ ] confirmation/reference

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/support/tickets`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 045. Ticket Detail

- **Group:** Support
- **Route:** `/app/support/{ticketId}`
- **Primary phase:** Phase 15
- **Purpose:** Conversation and status for one ticket.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Message thread
- [ ] status/priority
- [ ] assigned team if exposed
- [ ] attachments
- [ ] linked CDR/gateway
- [ ] reply
- [ ] close/reopen where policy allows

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/support/tickets/{id}`.
- [ ] Implement/verify `POST /api/v1/support/tickets/{id}/messages`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.
