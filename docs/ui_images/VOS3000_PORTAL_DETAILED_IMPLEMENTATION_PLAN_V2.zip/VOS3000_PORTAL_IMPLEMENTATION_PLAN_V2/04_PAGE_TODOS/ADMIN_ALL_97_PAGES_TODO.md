# Admin Portal — Complete Page Implementation TODOs

Total pages: **97**.

Every page below must be implemented or explicitly marked deferred with reason. This is the anti-skip checklist.

## 001. Admin Login

- **Group:** Access & Identity
- **Route:** `/admin/login`
- **Primary phase:** Phase 03
- **Purpose:** Secure entry point for internal operators.
- **Source basis:** ** VOS documents Administrator/Operator/Agent user types, lock state, invalid time, dynamic password and operation authorization. Portal authentication remains independent. [HYBRID]

### Feature TODO
- [ ] Email/login name and password
- [ ] Optional TOTP/MFA challenge
- [ ] Remember-device policy
- [ ] Rate-limit and temporary lockout
- [ ] Display environment/server label so operators know which VOS instance they are accessing
- [ ] Security event logging for successful/failed login

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/admin/auth/login`.
- [ ] Implement/verify `POST /api/v1/admin/auth/mfa/verify`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 002. MFA Challenge

- **Group:** Access & Identity
- **Route:** `/admin/mfa`
- **Primary phase:** Phase 03
- **Purpose:** Second-factor verification for privileged users.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] TOTP code entry
- [ ] Recovery code
- [ ] Trusted-device option subject to policy
- [ ] Re-authentication for dangerous actions
- [ ] Clear failure/expiry states

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/admin/auth/mfa/verify`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 003. Forgot / Reset Password

- **Group:** Access & Identity
- **Route:** `/admin/forgot-password`
- **Primary phase:** Phase 03
- **Purpose:** Secure password recovery without exposing VOS credentials.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Email-based reset
- [ ] Single-use expiring token
- [ ] Password policy
- [ ] Invalidate active sessions after reset
- [ ] Audit event

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/admin/auth/password/request`.
- [ ] Implement/verify `POST /api/v1/admin/auth/password/reset`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 004. Admin Sessions & Devices

- **Group:** Access & Identity
- **Route:** `/admin/settings/sessions`
- **Primary phase:** Phase 16
- **Purpose:** Review and terminate active admin sessions.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Current session highlight
- [ ] IP, browser, approximate location, created/last-active time
- [ ] Revoke one session
- [ ] Revoke all other sessions
- [ ] Suspicious-session marker

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/me/sessions`.
- [ ] Implement/verify `DELETE /api/v1/admin/me/sessions/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 005. Executive Dashboard

- **Group:** Command Center
- **Route:** `/admin`
- **Primary phase:** Phase 09
- **Purpose:** Top-level commercial and network snapshot.
- **Source basis:** ** VOS documents account balances, current calls, gateway metrics, billing, reports and alarms. Aggregation and visualization are [HYBRID].

### Feature TODO
- [ ] KPI cards: active customers, active calls, available/used channels, current CPS, today minutes, revenue, cost, gross margin, ASR, ACD, PDD
- [ ] Trend charts for calls/minutes/revenue/ASR/ACD
- [ ] Top customers by traffic and spend
- [ ] Top routes by traffic and margin
- [ ] Low-balance customers
- [ ] Offline/degraded gateways
- [ ] Current alarms
- [ ] Recent payments
- [ ] Time-range selector: today/24h/7d/30d/custom
- [ ] Drill-down from every KPI

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/dashboard/summary`.
- [ ] Implement/verify `GET /api/v1/admin/dashboard/timeseries`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 006. NOC Live Operations

- **Group:** Command Center
- **Route:** `/admin/noc`
- **Primary phase:** Phase 09
- **Purpose:** Real-time wallboard for network operations.
- **Source basis:** ** Online gateway, gateway-network and Current Call data are documented by VOS. [HYBRID]

### Feature TODO
- [ ] Live concurrency
- [ ] Current CPS
- [ ] Answered/failed call ratio
- [ ] ASR/ACD/PDD
- [ ] Gateway online/offline/degraded tiles
- [ ] Packet loss and network delay
- [ ] Top SIP/termination failures
- [ ] Alarm stream
- [ ] Auto-refresh/WebSocket connection status
- [ ] Fullscreen NOC mode

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/noc/summary`.
- [ ] Implement/verify `GET /api/v1/admin/noc/stream`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 007. System Health

- **Group:** Command Center
- **Route:** `/admin/system/health`
- **Primary phase:** Phase 16
- **Purpose:** Operational health of portal services and connected VOS components.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Portal API health
- [ ] VOS adapter connectivity
- [ ] CDR ingestion lag
- [ ] Webhook queue depth
- [ ] Payment webhook health
- [ ] Background job health
- [ ] Database/storage health
- [ ] Last successful sync per resource
- [ ] Incident banner

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/health`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 008. Alarm Center

- **Group:** Command Center
- **Route:** `/admin/alarms`
- **Primary phase:** Phase 16
- **Purpose:** Unified current and historical alarm workspace.
- **Source basis:** ** VOS documents system, network, disk, process, mapping, routing, balance and external-device alarms plus current/history alarms. Portal workflow is [HYBRID].

### Feature TODO
- [ ] Filters: severity, type, source, gateway, account, time
- [ ] Current vs historical tabs
- [ ] Acknowledge/assign/resolve workflow in portal
- [ ] Link alarm to gateway/customer/system page
- [ ] Notification policy preview
- [ ] Bulk acknowledge
- [ ] Export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/alarms`.
- [ ] Implement/verify `POST /api/v1/admin/alarms/{id}/ack`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 009. Customer Directory

- **Group:** Customers & Accounts
- **Route:** `/admin/customers`
- **Primary phase:** Phase 11
- **Purpose:** Primary customer list and lifecycle management.
- **Source basis:** ** VOS General Account contains account ID/name, balance, overdraft, billing rate, today consumption, gateway/phone counts and status. [HYBRID]

### Feature TODO
- [ ] Search by customer name, portal ID, VOS account ID, email, phone, gateway, IP
- [ ] Filters: active/suspended, low balance, agent/general, rate group, created date
- [ ] Columns: customer, VOS account, balance, overdraft/credit, today usage, gateways, channels, status, last activity
- [ ] Bulk export
- [ ] Bulk notification
- [ ] Create customer
- [ ] Suspend/enable selected where authorized

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/customers`.
- [ ] Implement/verify `POST /api/v1/admin/customers`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 010. Create Customer Wizard

- **Group:** Customers & Accounts
- **Route:** `/admin/customers/new`
- **Primary phase:** Phase 11
- **Purpose:** Controlled onboarding that creates portal identity and maps it to VOS.
- **Source basis:** ** Account creation, billing rate assignment, account status and agent hierarchy are VOS functions; exact create API is [VERIFY-API].

### Feature TODO
- [ ] Step 1 company/profile
- [ ] Step 2 portal owner credentials
- [ ] Step 3 VOS account mapping or create-new request
- [ ] Step 4 billing currency, credit/overdraft, expiry
- [ ] Step 5 rate group/private-rate policy
- [ ] Step 6 gateway/channel/CPS defaults
- [ ] Step 7 permissions/API access
- [ ] Review-and-create screen
- [ ] Rollback/compensation if one downstream step fails

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/admin/customers`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 011. Customer Overview

- **Group:** Customers & Accounts
- **Route:** `/admin/customers/{customerId}`
- **Primary phase:** Phase 11
- **Purpose:** 360-degree customer workspace.
- **Source basis:** ** [HYBRID]

### Feature TODO
- [ ] Header: status, VOS account ID, balance, credit, today/month spend, active calls
- [ ] Tabs: Overview, Billing, Gateways, Phones, Rates, CDR, Live Calls, Reports, API, Users, Tickets, Audit
- [ ] Quick actions: add funds, adjust credit, suspend, change rate, add gateway, impersonate portal user
- [ ] Risk banners: negative balance, expiring account, offline gateway, payment issue

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/customers/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 012. Customer Account Settings

- **Group:** Customers & Accounts
- **Route:** `/admin/customers/{customerId}/account`
- **Primary phase:** Phase 11
- **Purpose:** Edit VOS-account-facing commercial and lifecycle settings.
- **Source basis:** ** These fields are documented in VOS Account Management. Writes are [VERIFY-API].

### Feature TODO
- [ ] Account name
- [ ] VOS account mapping
- [ ] Current balance read-only
- [ ] Overdraft/credit limit
- [ ] Billing rate group
- [ ] Private rate indicator
- [ ] Expiry date
- [ ] Account status normal/locked
- [ ] Memo/internal notes
- [ ] Agent parent
- [ ] Account type/category where applicable
- [ ] Danger-zone actions: disable/enable/delete mapping

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/customers/{id}/account`.
- [ ] Implement/verify `PATCH /api/v1/admin/customers/{id}/account`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 013. Customer Balance & Adjustments

- **Group:** Customers & Accounts
- **Route:** `/admin/customers/{customerId}/balance`
- **Primary phase:** Phase 11
- **Purpose:** Financial balance controls with strict auditability.
- **Source basis:** ** VOS Payment supports Payment/Credit/Make Zero and historical records. [HYBRID]/[VERIFY-API]

### Feature TODO
- [ ] Current VOS balance
- [ ] Portal wallet balance if separate
- [ ] Overdraft/credit
- [ ] Add payment
- [ ] Add credit
- [ ] Make-zero only for authorized roles
- [ ] Adjustment memo mandatory
- [ ] Before/after balance preview
- [ ] Dual-control/approval option above configured threshold
- [ ] Complete adjustment history

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/customers/{id}/balance`.
- [ ] Implement/verify `POST /api/v1/admin/customers/{id}/adjustments`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 014. Customer Packages

- **Group:** Customers & Accounts
- **Route:** `/admin/customers/{customerId}/packages`
- **Primary phase:** Phase 11
- **Purpose:** Assign and inspect package subscriptions.
- **Source basis:** ** VOS Customer Package Management documents effective/invalid dates, priority and failed processing. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Package name
- [ ] Effective date
- [ ] Invalid time
- [ ] Priority
- [ ] Failed-processing mode
- [ ] Percentage rent
- [ ] Package period/rent/minimum consumption/free duration/free amount summary
- [ ] Add/remove package
- [ ] Future package schedule

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/customers/{id}/packages`.
- [ ] Implement/verify `POST /api/v1/admin/customers/{id}/packages`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 015. Customer Authorizations

- **Group:** Customers & Accounts
- **Route:** `/admin/customers/{customerId}/authorizations`
- **Primary phase:** Phase 11
- **Purpose:** Manage delegated account/gateway/phone/payment privileges.
- **Source basis:** ** VOS explicitly documents these authorization categories and subaccount restrictions. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Add/delete/modify account permission
- [ ] Add/delete/modify phone permission
- [ ] Phone-card permission
- [ ] Add/delete gateway permission
- [ ] Modify gateway information
- [ ] Modify gateway capacity
- [ ] Payment for this account
- [ ] Payment for subaccounts
- [ ] Number-section limitation
- [ ] Inherited/explicit permission visualization

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/customers/{id}/authorizations`.
- [ ] Implement/verify `PUT /api/v1/admin/customers/{id}/authorizations`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 016. Agent & Subaccount Tree

- **Group:** Customers & Accounts
- **Route:** `/admin/customers/{customerId}/subaccounts`
- **Primary phase:** Phase 11
- **Purpose:** Visualize and manage agent hierarchies.
- **Source basis:** ** VOS documents Agent Account and direct/all subaccount views. [VOS]/[HYBRID]

### Feature TODO
- [ ] Tree and table view
- [ ] Direct vs all descendants
- [ ] Parent agent
- [ ] Balances and status per node
- [ ] Create child account
- [ ] Move/reparent only if safe and supported
- [ ] Permission inheritance preview
- [ ] Aggregate spend/traffic

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/customers/{id}/subaccounts`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 017. Customer Number Section Limits

- **Group:** Customers & Accounts
- **Route:** `/admin/customers/{customerId}/number-limits`
- **Primary phase:** Phase 11
- **Purpose:** Limit number ranges that a customer/agent may allocate.
- **Source basis:** ** VOS Number Section Limitation is documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Begin number
- [ ] End number
- [ ] Validation for overlap
- [ ] Agent inheritance display
- [ ] Add/remove range
- [ ] Audit changes

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/customers/{id}/number-limits`.
- [ ] Implement/verify `PUT /api/v1/admin/customers/{id}/number-limits`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 018. Mapping Gateways

- **Group:** Gateways & Routing
- **Route:** `/admin/gateways/mapping`
- **Primary phase:** Phase 12
- **Purpose:** Manage customer-side ingress/mapping gateways.
- **Source basis:** ** Mapping Gateway management and online metrics are documented by VOS. Writes [VERIFY-API].

### Feature TODO
- [ ] Search/filter by gateway, customer, IP, status, softswitch
- [ ] Columns: name, account, IP, registration mode, line limit, active calls, CPS, ASR, ACD, status
- [ ] Create/edit/disable
- [ ] Open live calls
- [ ] Open network quality
- [ ] Bulk export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/gateways/mapping`.
- [ ] Implement/verify `POST /api/v1/admin/gateways/mapping`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 019. Mapping Gateway Detail

- **Group:** Gateways & Routing
- **Route:** `/admin/gateways/mapping/{gatewayId}`
- **Primary phase:** Phase 12
- **Purpose:** Complete ingress gateway configuration and telemetry.
- **Source basis:** ** VOS documents these mapping-gateway fields. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Overview
- [ ] Customer/account mapping
- [ ] Gateway type static/dynamic
- [ ] IP(s) and signaling port
- [ ] Line limit
- [ ] Routing gateway group/allow-forbid controls
- [ ] Process timeout
- [ ] Protect-route enable time
- [ ] Conversation limit
- [ ] Media proxy and RTP-interrupt settings
- [ ] Registered IP/status
- [ ] Current calls
- [ ] Network quality
- [ ] Audit history

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/gateways/mapping/{id}`.
- [ ] Implement/verify `PATCH /api/v1/admin/gateways/mapping/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 020. Routing Gateways

- **Group:** Gateways & Routing
- **Route:** `/admin/gateways/routing`
- **Primary phase:** Phase 12
- **Purpose:** Manage carrier-side egress gateways.
- **Source basis:** ** Routing Gateway and Online Routing Gateway are documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Carrier/customer association
- [ ] Gateway prefix
- [ ] IP/registration
- [ ] Line limit
- [ ] Current calls
- [ ] ASR/ACD
- [ ] CPS
- [ ] rate/cost indicator
- [ ] route/protect-route status
- [ ] softswitch
- [ ] online status
- [ ] bulk actions

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/gateways/routing`.
- [ ] Implement/verify `POST /api/v1/admin/gateways/routing`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 021. Routing Gateway Detail

- **Group:** Gateways & Routing
- **Route:** `/admin/gateways/routing/{gatewayId}`
- **Primary phase:** Phase 12
- **Purpose:** Carrier gateway configuration, quality and route behavior.
- **Source basis:** ** VOS documents rate limiting, tracing, protect routes and online routing metrics. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] General configuration
- [ ] Registration/security
- [ ] Capacity/line limit
- [ ] Rate limit/CPS
- [ ] Protection/failover
- [ ] Caller number pool where supported
- [ ] Signaling/register tracing controls
- [ ] ASR/ACD and current call count
- [ ] Registered/local IP
- [ ] Network quality
- [ ] Cost/rate references
- [ ] Audit

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/gateways/routing/{id}`.
- [ ] Implement/verify `PATCH /api/v1/admin/gateways/routing/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 022. Online Gateways

- **Group:** Gateways & Routing
- **Route:** `/admin/gateways/online`
- **Primary phase:** Phase 12
- **Purpose:** Single live view of all online routing and mapping gateways.
- **Source basis:** ** Directly maps documented Online Routing/Mapping Gateway fields. [VOS]

### Feature TODO
- [ ] Tabs mapping/routing
- [ ] Current sessions vs capacity
- [ ] ASR
- [ ] ACD
- [ ] CPS
- [ ] registered IP
- [ ] registration time
- [ ] last update
- [ ] online duration
- [ ] encryption
- [ ] softswitch
- [ ] open current calls

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/gateways/online`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 023. Gateway Network Quality

- **Group:** Gateways & Routing
- **Route:** `/admin/gateways/network`
- **Primary phase:** Phase 12
- **Purpose:** Observe network path quality per gateway.
- **Source basis:** ** VOS documents Mapping Gateway Network and Routing Gateway Network. Historical chart is [HYBRID].

### Feature TODO
- [ ] Gateway
- [ ] Remote IP
- [ ] Network quality
- [ ] Packet loss
- [ ] Network delay
- [ ] Device ID
- [ ] Mapping/routing type
- [ ] History chart maintained by portal
- [ ] Threshold filters
- [ ] Degraded-only toggle

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/gateways/network`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 024. Gateway Status Analytics

- **Group:** Gateways & Routing
- **Route:** `/admin/gateways/status`
- **Primary phase:** Phase 12
- **Purpose:** Aggregated gateway call outcomes.
- **Source basis:** ** VOS Gateway Status fields are documented. [VOS]

### Feature TODO
- [ ] Gateway
- [ ] Total calls
- [ ] Success
- [ ] Callee rejected
- [ ] Trunk error
- [ ] Network error
- [ ] Caller abandon
- [ ] Average talk duration
- [ ] Total call time
- [ ] IP
- [ ] Starting time
- [ ] Success/failure percentages

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/gateways/status`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 025. Gateway Groups

- **Group:** Gateways & Routing
- **Route:** `/admin/gateway-groups`
- **Primary phase:** Phase 09
- **Purpose:** Organize gateways for shared capacity and routing policy.
- **Source basis:** ** VOS documents Gateway Group. Exact API [VERIFY-API].

### Feature TODO
- [ ] Group name
- [ ] Type
- [ ] Member gateways
- [ ] Capacity summary
- [ ] Active calls
- [ ] Policy/notes
- [ ] Add/remove members
- [ ] Impact preview

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/gateway-groups`.
- [ ] Implement/verify `POST /api/v1/admin/gateway-groups`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 026. Registration Management

- **Group:** Gateways & Routing
- **Route:** `/admin/registrations`
- **Primary phase:** Phase 12
- **Purpose:** Manage registrations to other SIP/H323 platforms.
- **Source basis:** ** Fields are documented in VOS Registration Management. Writes [VERIFY-API].

### Feature TODO
- [ ] Mark/identifier
- [ ] Username
- [ ] Masked authentication password
- [ ] Server IP
- [ ] Line limit
- [ ] Signaling port
- [ ] Encryption
- [ ] Host name
- [ ] SIP proxy
- [ ] User-Agent
- [ ] Local IP/port
- [ ] Test/trace link

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/registrations`.
- [ ] Implement/verify `POST /api/v1/admin/registrations`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 027. Routing Analysis

- **Group:** Gateways & Routing
- **Route:** `/admin/tools/routing-analysis`
- **Primary phase:** Phase 12
- **Purpose:** Simulate route selection before changing production.
- **Source basis:** ** VOS Routing Analysis documents these inputs/outputs. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Authentication method: existing device or static IP
- [ ] Device type and ID
- [ ] Caller
- [ ] Callee
- [ ] Softswitch
- [ ] Output actual caller device/account
- [ ] Routing caller/callee after rewrite
- [ ] Customer rate/minute
- [ ] Available time
- [ ] Candidate routes with egress rate
- [ ] Rate deviation/margin
- [ ] Route detail and sequence

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/admin/tools/routing-analysis`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 028. Network Test

- **Group:** Gateways & Routing
- **Route:** `/admin/tools/network-test`
- **Primary phase:** Phase 12
- **Purpose:** Test reachability/network condition to a remote IP.
- **Source basis:** ** VOS Network Test supports special-format and ICMP testing. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Remote IP
- [ ] Configuration port
- [ ] Authorized local IP
- [ ] Packet type
- [ ] Run test
- [ ] Result history
- [ ] Copy diagnostics

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/admin/tools/network-test`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 029. Domain Management

- **Group:** Gateways & Routing
- **Route:** `/admin/routing/domains`
- **Primary phase:** Phase 12
- **Purpose:** Manage domains used by the VOS environment.
- **Source basis:** ** VOS has Domain Management. Field-level API requires verification. [VERIFY-API]

### Feature TODO
- [ ] Domain list
- [ ] Resolution/status
- [ ] Associated gateway/service
- [ ] Last update
- [ ] Add/edit/delete subject to supported interface

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/domains`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 030. Prohibited Media IP

- **Group:** Gateways & Routing
- **Route:** `/admin/routing/prohibited-media-ips`
- **Primary phase:** Phase 12
- **Purpose:** Manage disallowed media/RTP addresses.
- **Source basis:** ** VOS includes Prohibited Media IP management. [VERIFY-API]

### Feature TODO
- [ ] IP/CIDR
- [ ] Reason
- [ ] Created by/time
- [ ] Enabled state
- [ ] Search/filter
- [ ] Add/remove

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/prohibited-media-ips`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 031. Softswitches

- **Group:** Gateways & Routing
- **Route:** `/admin/softswitches`
- **Primary phase:** Phase 12
- **Purpose:** View/manage softswitch instances and their operational settings.
- **Source basis:** ** VOS documents Softswitch Management. [VERIFY-API]

### Feature TODO
- [ ] Softswitch list/status
- [ ] Assigned gateways
- [ ] Current load
- [ ] IP
- [ ] Configuration entry point
- [ ] Link to system parameters and monitors

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/softswitches`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 032. Phone Directory

- **Group:** Phones & Terminals
- **Route:** `/admin/phones`
- **Primary phase:** Phase 12
- **Purpose:** Manage VOS phone/terminal objects.
- **Source basis:** ** VOS Phone Management documents these fields. Writes [VERIFY-API].

### Feature TODO
- [ ] Phone number
- [ ] Account
- [ ] Lock state
- [ ] authorization type
- [ ] monthly consumption
- [ ] billing rate/private rate
- [ ] routing group
- [ ] DID/DDI
- [ ] softswitch
- [ ] registration type
- [ ] IP/port
- [ ] line/in/out limits
- [ ] online status

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/phones`.
- [ ] Implement/verify `POST /api/v1/admin/phones`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 033. Phone Detail

- **Group:** Phones & Terminals
- **Route:** `/admin/phones/{phoneId}`
- **Primary phase:** Phase 12
- **Purpose:** Configure a single phone/terminal and supplementary services.
- **Source basis:** ** VOS documents phone management, supplementary services and advanced configuration. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Registration credentials with secret masking/reset
- [ ] Caller-ID display
- [ ] Lock outgoing/incoming/all
- [ ] Authorization type
- [ ] Monthly min/max/service fee
- [ ] Private rate
- [ ] Account assignment
- [ ] DID/DDI
- [ ] Reverse charging
- [ ] Self-service password reset
- [ ] Call-in/out and line limits
- [ ] Caller/callee list groups
- [ ] Forwarding/DND/transfer controls
- [ ] Protocol/IP/media/DTMF/codec settings
- [ ] Routing strategies

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/phones/{id}`.
- [ ] Implement/verify `PATCH /api/v1/admin/phones/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 034. Online Phones

- **Group:** Phones & Terminals
- **Route:** `/admin/phones/online`
- **Primary phase:** Phase 12
- **Purpose:** Live registration and capacity view.
- **Source basis:** ** VOS Online Phone fields are documented. [VOS]

### Feature TODO
- [ ] Phone number
- [ ] Current calls
- [ ] Line limit
- [ ] In/out capacity and limits
- [ ] Device model
- [ ] Protocol
- [ ] Registered IP
- [ ] Registration/update time
- [ ] Duration
- [ ] Encryption
- [ ] Tracing state
- [ ] Softswitch

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/phones/online`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 035. Live Calls

- **Group:** Live Calls & Diagnostics
- **Route:** `/admin/calls/live`
- **Primary phase:** Phase 08
- **Purpose:** Real-time view of all active sessions.
- **Source basis:** ** Current Call fields are explicitly documented by VOS. [VOS]/[HYBRID]

### Feature TODO
- [ ] Caller/callee
- [ ] Mapping/routing gateway
- [ ] Connect time
- [ ] Duration
- [ ] Connecting duration
- [ ] PDD
- [ ] Codec
- [ ] Packet/traffic indicators
- [ ] Caller/callee IP and RTP IP
- [ ] DTMF mode
- [ ] Media routing
- [ ] Device names
- [ ] Encryption
- [ ] Softswitch
- [ ] Filters by customer/gateway/caller/callee/duration
- [ ] WebSocket/SSE updates

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/calls/live`.
- [ ] Implement/verify `GET /api/v1/admin/calls/live/stream`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 036. Live Call Detail

- **Group:** Live Calls & Diagnostics
- **Route:** `/admin/calls/live/{callId}`
- **Primary phase:** Phase 08
- **Purpose:** Deep single-call inspection and safe operator actions.
- **Source basis:** ** VOS Current Call includes disconnect, audio traffic, voice samples and call analysis actions. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] All live-call fields
- [ ] Leg-by-leg topology
- [ ] Customer and carrier account links
- [ ] Media/codec panel
- [ ] Call analysis link
- [ ] Audio-traffic/voice-sample actions only for highly privileged roles
- [ ] Disconnect-call button with confirmation and mandatory reason
- [ ] Audit dangerous actions

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/calls/live/{id}`.
- [ ] Implement/verify `POST /api/v1/admin/calls/live/{id}/disconnect`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 037. Call Analysis

- **Group:** Live Calls & Diagnostics
- **Route:** `/admin/diagnostics/call-analysis`
- **Primary phase:** Phase 09
- **Purpose:** Signaling-level troubleshooting.
- **Source basis:** ** VOS Call Analysis is documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Serial number search
- [ ] Caller signaling
- [ ] Callee signaling
- [ ] Softswitch memo
- [ ] Timestamp sequence
- [ ] Export signaling
- [ ] Import signaling file only if needed
- [ ] Link from CDR/live call

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/diagnostics/call-analysis/{serial}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 038. Registration Analysis

- **Group:** Live Calls & Diagnostics
- **Route:** `/admin/diagnostics/registration-analysis`
- **Primary phase:** Phase 09
- **Purpose:** Analyze registration signaling problems.
- **Source basis:** ** VOS Registration Analysis is documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Serial number
- [ ] Registration signaling
- [ ] Softswitch memo
- [ ] Time
- [ ] Filter/export
- [ ] Link to phone/gateway

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/diagnostics/registration-analysis`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 039. Recent CDR

- **Group:** CDR & Call Analytics
- **Route:** `/admin/cdr/recent`
- **Primary phase:** Phase 09
- **Purpose:** Fast access to most recent records.
- **Source basis:** ** VOS Recent CDR explicitly returns recent records and references CDR fields. [VOS]

### Feature TODO
- [ ] Last 1,000 by default according to VOS behavior
- [ ] Caller/callee
- [ ] begin/end
- [ ] duration/charged duration
- [ ] charges/expense
- [ ] termination reason
- [ ] gateway/account/IP
- [ ] quick customer and call detail links

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/cdr/recent`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 040. CDR Explorer

- **Group:** CDR & Call Analytics
- **Route:** `/admin/cdr`
- **Primary phase:** Phase 09
- **Purpose:** Global historical CDR query and export.
- **Source basis:** ** VOS CDR documents caller/callee, times, actual/charged duration, charge/expense, gateways, IPs, account/agent, call type, rewrite numbers, Call-IDs, reason and serial. [VOS]/[HYBRID]

### Feature TODO
- [ ] Filters: start/end time mode, caller, callee, account, agent, mapping/routing gateway, caller/callee IP, call type, area/prefix, duration, charge, expense, termination reason, hangup side, Call-ID, serial number
- [ ] Columns selectable/persisted
- [ ] Server-side pagination
- [ ] Saved views
- [ ] CSV/XLSX export job for large ranges
- [ ] Aggregate footer totals
- [ ] No unrestricted wildcard export for non-privileged roles

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/cdr`.
- [ ] Implement/verify `POST /api/v1/admin/cdr/exports`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 041. CDR Detail

- **Group:** CDR & Call Analytics
- **Route:** `/admin/cdr/{cdrId}`
- **Primary phase:** Phase 09
- **Purpose:** Human-readable single-call record.
- **Source basis:** ** Fields map directly to VOS CDR. Margin display is [HYBRID].

### Feature TODO
- [ ] Timeline: begin → routing → connect → end
- [ ] Caller/callee original and outbound rewritten values
- [ ] Actual vs charged duration
- [ ] Customer charge/tax
- [ ] Carrier expense/tax
- [ ] Gross margin
- [ ] Account/agent
- [ ] Mapping/routing gateway
- [ ] Caller/callee IP
- [ ] Call type/area
- [ ] Termination reason/hangup side
- [ ] Billing method/mode
- [ ] PDD/continue/connect delay
- [ ] Calling/called Call-ID
- [ ] Serial
- [ ] Open call analysis

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/cdr/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 042. Failure Analytics

- **Group:** CDR & Call Analytics
- **Route:** `/admin/analytics/failures`
- **Primary phase:** Phase 09
- **Purpose:** Turn termination reasons into actionable operations intelligence.
- **Source basis:** ** VOS records termination reason and gateway status outcome categories; analytics are [HYBRID].

### Feature TODO
- [ ] Failure distribution
- [ ] Trend by hour/day
- [ ] Breakdown by customer/carrier/gateway/destination
- [ ] Top termination reasons
- [ ] Network vs trunk vs callee-reject vs caller-abandon groupings
- [ ] Drill-through to CDR
- [ ] Threshold alerts

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/analytics/failures`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 043. Connect Analysis

- **Group:** CDR & Call Analytics
- **Route:** `/admin/analytics/connect`
- **Primary phase:** Phase 09
- **Purpose:** Expose VOS CDR analysis for connection behavior.
- **Source basis:** ** VOS has CDR Analysis > Connect Analysis. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Time filter
- [ ] Customer/gateway/destination filter
- [ ] ASR/connection KPIs
- [ ] Trend/chart
- [ ] Drill to source CDR

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/analytics/connect`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 044. Interrupt Analysis

- **Group:** CDR & Call Analytics
- **Route:** `/admin/analytics/interrupt`
- **Primary phase:** Phase 09
- **Purpose:** Analyze interrupted calls.
- **Source basis:** ** VOS has Interrupt Analysis. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Time/destination/customer/gateway filters
- [ ] Interrupt distribution
- [ ] Reason and duration buckets
- [ ] Drill to CDR

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/analytics/interrupt`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 045. Call Distribution

- **Group:** CDR & Call Analytics
- **Route:** `/admin/analytics/distribution`
- **Primary phase:** Phase 09
- **Purpose:** Understand traffic distribution.
- **Source basis:** ** VOS has Call Distribution analysis. [VOS]/[HYBRID]

### Feature TODO
- [ ] By hour
- [ ] destination
- [ ] account
- [ ] gateway
- [ ] duration band
- [ ] call type
- [ ] heatmaps and tables

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/analytics/distribution`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 046. Historical Performance

- **Group:** CDR & Call Analytics
- **Route:** `/admin/analytics/historical-performance`
- **Primary phase:** Phase 09
- **Purpose:** Longitudinal quality and traffic trend.
- **Source basis:** ** VOS has Historical Performance. [VOS]/[HYBRID]

### Feature TODO
- [ ] ASR/ACD/minutes/calls over time
- [ ] Compare periods
- [ ] Customer/gateway filter
- [ ] Export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/analytics/historical-performance`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 047. Gateway Performance

- **Group:** CDR & Call Analytics
- **Route:** `/admin/analytics/gateway-performance`
- **Primary phase:** Phase 09
- **Purpose:** Compare gateway quality and utilization.
- **Source basis:** ** VOS has Gateway Performance; business overlays are [HYBRID].

### Feature TODO
- [ ] ASR
- [ ] ACD
- [ ] calls
- [ ] minutes
- [ ] failure rate
- [ ] cost/margin overlay
- [ ] capacity utilization
- [ ] ranking

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/analytics/gateway-performance`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 048. Rate Groups

- **Group:** Rates, Packages & Commercial Routing
- **Route:** `/admin/rates/groups`
- **Primary phase:** Phase 13
- **Purpose:** Manage reusable customer/carrier rate groups.
- **Source basis:** ** VOS Rate Group Management documents these concepts. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Group name
- [ ] Number of rates
- [ ] Number of using accounts
- [ ] memo
- [ ] creator
- [ ] authorization visibility
- [ ] create/duplicate/archive
- [ ] open rates

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/rates/groups`.
- [ ] Implement/verify `POST /api/v1/admin/rates/groups`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 049. Rate Editor

- **Group:** Rates, Packages & Commercial Routing
- **Route:** `/admin/rates/groups/{groupId}`
- **Primary phase:** Phase 13
- **Purpose:** Search, import, edit and validate rate prefixes.
- **Source basis:** ** VOS documents longest-prefix matching, rate type, billing rate/cycle and import/export. Future workflow is [HYBRID].

### Feature TODO
- [ ] Rate prefix
- [ ] area prefix/name
- [ ] rate type
- [ ] billing rate
- [ ] billing cycle
- [ ] rate/minute
- [ ] lock
- [ ] section rates
- [ ] tax
- [ ] bulk import/export
- [ ] prefix collision validation
- [ ] effective/future-change wrapper in portal
- [ ] impact count of attached accounts

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/rates/groups/{id}/rates`.
- [ ] Implement/verify `PUT /api/v1/admin/rates/groups/{id}/rates`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 050. Rate Import Jobs

- **Group:** Rates, Packages & Commercial Routing
- **Route:** `/admin/rates/imports`
- **Primary phase:** Phase 13
- **Purpose:** Safe large-rate-sheet ingestion.
- **Source basis:** ** Built around VOS import/export capability. [HYBRID]/[VERIFY-API]

### Feature TODO
- [ ] Upload CSV/XLSX
- [ ] Map columns
- [ ] Normalize prefixes
- [ ] Preview add/change/delete counts
- [ ] Validation errors
- [ ] Duplicate/overlap warnings
- [ ] Dry run
- [ ] Approval workflow
- [ ] Apply job
- [ ] Rollback snapshot maintained by portal

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/admin/rates/imports`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 051. Rate Lookup

- **Group:** Rates, Packages & Commercial Routing
- **Route:** `/admin/rates/lookup`
- **Primary phase:** Phase 13
- **Purpose:** Resolve a number to matched rate and route context.
- **Source basis:** ** [HYBRID]

### Feature TODO
- [ ] Input number and optional customer
- [ ] Matched prefix
- [ ] area
- [ ] rate type
- [ ] customer rate
- [ ] candidate carrier cost
- [ ] margin
- [ ] routing analysis shortcut

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/rates/lookup`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 052. Package Groups

- **Group:** Rates, Packages & Commercial Routing
- **Route:** `/admin/packages`
- **Primary phase:** Phase 13
- **Purpose:** Manage VOS billing packages.
- **Source basis:** ** VOS Package Management documents these fields. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Package name
- [ ] rent period/unit
- [ ] rent fee
- [ ] minimum consumption
- [ ] effective-spending limit
- [ ] period rates
- [ ] free duration
- [ ] free money
- [ ] using accounts
- [ ] authorization

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/packages`.
- [ ] Implement/verify `POST /api/v1/admin/packages`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 053. Package Period Rates

- **Group:** Rates, Packages & Commercial Routing
- **Route:** `/admin/packages/{packageId}/period-rates`
- **Primary phase:** Phase 13
- **Purpose:** Define time-window-specific package rates.
- **Source basis:** ** VOS Package Period Rate Management is documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Period type
- [ ] begin/end date
- [ ] begin/end time
- [ ] period rate
- [ ] overlap validation
- [ ] calendar preview

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/packages/{id}/period-rates`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 054. Package Free Duration

- **Group:** Rates, Packages & Commercial Routing
- **Route:** `/admin/packages/{packageId}/free-duration`
- **Primary phase:** Phase 13
- **Purpose:** Manage included call time.
- **Source basis:** ** VOS Package Free Duration Management is documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Begin/end time
- [ ] area prefix
- [ ] free duration
- [ ] billing cycle
- [ ] memo
- [ ] usage preview

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/packages/{id}/free-duration`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 055. Margin Monitor

- **Group:** Rates, Packages & Commercial Routing
- **Route:** `/admin/commercial/margins`
- **Primary phase:** Phase 09
- **Purpose:** Detect unprofitable customer/carrier combinations.
- **Source basis:** ** VOS Routing Analysis exposes customer rate, egress rate and rate deviation; consolidated monitoring is [HYBRID].

### Feature TODO
- [ ] Customer rate vs carrier cost
- [ ] Margin/minute
- [ ] Estimated daily margin
- [ ] Negative-margin destinations
- [ ] Gateway/customer drilldowns
- [ ] Threshold alarm

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/commercial/margins`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 056. Payment Ledger

- **Group:** Billing, Payments & Settlement
- **Route:** `/admin/payments`
- **Primary phase:** Phase 14
- **Purpose:** All customer payments and portal payment-processor events.
- **Source basis:** ** VOS Payment Record documents account, amount, balance after payment, type, time, mode, payment user, memo, agent and serial. Portal reconciliation is [HYBRID].

### Feature TODO
- [ ] Filters account/customer/type/mode/status/date/amount
- [ ] VOS payment amount and resulting balance
- [ ] Portal processor transaction ID
- [ ] Payment/Credit/Create Account categorization where available
- [ ] Manual adjustment distinction
- [ ] Reconciliation state
- [ ] Receipt link
- [ ] Export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/payments`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 057. Manual Payment / Credit

- **Group:** Billing, Payments & Settlement
- **Route:** `/admin/payments/new`
- **Primary phase:** Phase 14
- **Purpose:** Controlled operator-initiated financial adjustment.
- **Source basis:** ** VOS supports Payment/Credit/Make Zero. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Customer/account lookup
- [ ] Action: payment/credit/make-zero subject to role
- [ ] Amount
- [ ] Currency
- [ ] memo required
- [ ] Before/after balance
- [ ] Approval if threshold exceeded
- [ ] Idempotency key
- [ ] Result and serial/reference

### API / Backend TODO
- [ ] Implement/verify `POST /api/v1/admin/payments`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 058. Revenue Details

- **Group:** Billing, Payments & Settlement
- **Route:** `/admin/billing/revenue`
- **Primary phase:** Phase 14
- **Purpose:** Revenue consumption analysis.
- **Source basis:** ** VOS Bill Query includes Revenue Details. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Time period
- [ ] account/customer
- [ ] call types
- [ ] call charges
- [ ] package amounts
- [ ] minutes
- [ ] CDR counts
- [ ] export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/billing/revenue`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 059. Gateway Bills

- **Group:** Billing, Payments & Settlement
- **Route:** `/admin/billing/gateway`
- **Primary phase:** Phase 14
- **Purpose:** Consumption/billing by mapping gateway.
- **Source basis:** ** VOS Gateway Bill is documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Gateway
- [ ] IP
- [ ] account
- [ ] period
- [ ] calls/minutes/charges
- [ ] export
- [ ] drill to CDR

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/billing/gateway`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 060. Phone Bills

- **Group:** Billing, Payments & Settlement
- **Route:** `/admin/billing/phone`
- **Primary phase:** Phase 14
- **Purpose:** Consumption/billing by phone.
- **Source basis:** ** VOS Phone Bill exists. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Phone
- [ ] account
- [ ] period
- [ ] usage/charges
- [ ] export
- [ ] drill to CDR

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/billing/phone`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 061. Account Balance Report

- **Group:** Billing, Payments & Settlement
- **Route:** `/admin/billing/account-balance`
- **Primary phase:** Phase 11
- **Purpose:** Portfolio-level balance reporting.
- **Source basis:** ** VOS Account Balance query/report exists. [VOS]/[HYBRID]

### Feature TODO
- [ ] Customer/account
- [ ] current balance
- [ ] credit/overdraft
- [ ] status
- [ ] low-balance threshold
- [ ] agent hierarchy
- [ ] export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/billing/account-balance`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 062. Clearing & Settlement

- **Group:** Billing, Payments & Settlement
- **Route:** `/admin/settlement`
- **Primary phase:** Phase 14
- **Purpose:** Carrier/customer settlement workspace.
- **Source basis:** ** VOS documents clearing queries/reports and summary of financial settlement. [VOS]/[HYBRID]

### Feature TODO
- [ ] Clearing account detail
- [ ] gateway details
- [ ] clearing balance
- [ ] settlement period
- [ ] reconciliation flags
- [ ] export
- [ ] summary

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/settlement`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 063. Report Center

- **Group:** Reports
- **Route:** `/admin/reports`
- **Primary phase:** Phase 15
- **Purpose:** Single catalog for all operational, billing and analysis reports.
- **Source basis:** ** VOS includes Data Report and Report Management; scheduling UX is [HYBRID].

### Feature TODO
- [ ] Categories: billing, cards, clearing, analysis, finance, quality, customer
- [ ] Saved report presets
- [ ] Run now
- [ ] Async export
- [ ] Schedule report
- [ ] Share to approved recipient
- [ ] Report history

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/reports`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 064. Gateway Analysis Reports

- **Group:** Reports
- **Route:** `/admin/reports/gateways`
- **Primary phase:** Phase 12
- **Purpose:** Mapping/routing gateway and area analysis reports.
- **Source basis:** ** VOS documents these Analysis Reports. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Mapping gateway analysis
- [ ] Routing gateway analysis
- [ ] Mapping/routing area analysis
- [ ] Cross-area analysis
- [ ] time and gateway filters
- [ ] export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/reports/gateways`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 065. Agent Income Report

- **Group:** Reports
- **Route:** `/admin/reports/agent-income`
- **Primary phase:** Phase 15
- **Purpose:** Agent hierarchy income view.
- **Source basis:** ** VOS Agent Income Report exists. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Agent
- [ ] period
- [ ] subaccounts
- [ ] income/usage
- [ ] export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/reports/agent-income`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 066. Scheduled Reports

- **Group:** Reports
- **Route:** `/admin/reports/schedules`
- **Primary phase:** Phase 15
- **Purpose:** Portal-managed report delivery.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Report template
- [ ] filters
- [ ] frequency
- [ ] timezone
- [ ] recipients
- [ ] format
- [ ] last/next run
- [ ] failure status
- [ ] pause/resume

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/report-schedules`.
- [ ] Implement/verify `POST /api/v1/admin/report-schedules`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 067. Number Sections

- **Group:** Number Management
- **Route:** `/admin/numbers/sections`
- **Primary phase:** Phase 13
- **Purpose:** Query and organize allowed number ranges/prefixes.
- **Source basis:** ** VOS Number Section Query exists. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Search prefix/range
- [ ] customer/agent ownership context
- [ ] export
- [ ] link to account limits

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/numbers/sections`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 068. Area Information

- **Group:** Number Management
- **Route:** `/admin/numbers/areas`
- **Primary phase:** Phase 13
- **Purpose:** Map prefixes to human-readable destinations.
- **Source basis:** ** VOS Area Information is used for rate display/matching. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Area prefix
- [ ] area name
- [ ] memo
- [ ] longest-match behavior note
- [ ] import/export wrapper

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/numbers/areas`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 069. Number Transform

- **Group:** Number Management
- **Route:** `/admin/numbers/transforms`
- **Primary phase:** Phase 13
- **Purpose:** Manage number rewrite/transform rules.
- **Source basis:** ** VOS Number Transform and rewrite rules are documented. Exact fields/API [VERIFY-API].

### Feature TODO
- [ ] Rule list
- [ ] source pattern
- [ ] target
- [ ] scope
- [ ] priority/order where supported
- [ ] test input/output
- [ ] impact preview
- [ ] audit

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/numbers/transforms`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 070. Black / White List Groups

- **Group:** Number Management
- **Route:** `/admin/numbers/lists`
- **Primary phase:** Phase 13
- **Purpose:** Manage caller/callee full-match list groups.
- **Source basis:** ** VOS Black/White List Group is documented as full-match and usable by gateways/phones. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Group name
- [ ] memo
- [ ] member numbers
- [ ] search/import/export
- [ ] usage references to gateways/phones
- [ ] bulk add/remove

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/numbers/lists`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 071. System White List

- **Group:** Number Management
- **Route:** `/admin/numbers/system-whitelist`
- **Primary phase:** Phase 13
- **Purpose:** Manage system-level allowed phone numbers.
- **Source basis:** ** VOS System White List is documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Phone number
- [ ] memo
- [ ] add/remove
- [ ] search/export

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/numbers/system-whitelist`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 072. Dynamic Black List

- **Group:** Number Management
- **Route:** `/admin/numbers/dynamic-blacklist`
- **Primary phase:** Phase 13
- **Purpose:** Review and manage dynamically blocked numbers.
- **Source basis:** ** VOS Dynamic Black List fields are documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Phone number
- [ ] type malicious/no-answer
- [ ] effective date
- [ ] expiration
- [ ] last call time
- [ ] softswitch
- [ ] manual add/remove/expire subject to VOS support

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/numbers/dynamic-blacklist`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 073. Admin Users

- **Group:** Admin Users, Roles & Audit
- **Route:** `/admin/security/users`
- **Primary phase:** Phase 03
- **Purpose:** Manage internal operator identities.
- **Source basis:** ** VOS user management documents login/name/type/lock/invalid time/dynamic password. Portal identity is [HYBRID].

### Feature TODO
- [ ] Login name
- [ ] display name
- [ ] portal role
- [ ] mapped VOS user where required
- [ ] status
- [ ] expiry
- [ ] last login
- [ ] last password change
- [ ] MFA state
- [ ] create/lock/disable/reset

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/security/users`.
- [ ] Implement/verify `POST /api/v1/admin/security/users`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 074. Roles & Permissions

- **Group:** Admin Users, Roles & Audit
- **Route:** `/admin/security/roles`
- **Primary phase:** Phase 03
- **Purpose:** Fine-grained RBAC independent of the VOS client.
- **Source basis:** ** VOS documents navigation preview, detailed view/edit privilege and operation authorization. Portal RBAC mirrors the principle. [HYBRID]

### Feature TODO
- [ ] Role templates: Super Admin, NOC, Billing, Support, Sales, Read Only
- [ ] Resource/action matrix
- [ ] View/edit distinction
- [ ] Dangerous actions separated: disconnect call, payment adjustment, rate apply, gateway delete, system parameter write
- [ ] Customer-scope constraints
- [ ] Permission diff/preview
- [ ] Clone role

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/security/roles`.
- [ ] Implement/verify `PUT /api/v1/admin/security/roles/{id}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 075. Online Admin Users

- **Group:** Admin Users, Roles & Audit
- **Route:** `/admin/security/online-users`
- **Primary phase:** Phase 09
- **Purpose:** Show current VOS/portal user sessions where available.
- **Source basis:** ** VOS includes Online User query. Portal session data is [HYBRID].

### Feature TODO
- [ ] User
- [ ] session source
- [ ] login time
- [ ] last activity
- [ ] IP
- [ ] portal vs VOS indicator

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/security/online-users`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 076. Portal Audit Log

- **Group:** Admin Users, Roles & Audit
- **Route:** `/admin/audit`
- **Primary phase:** Phase 09
- **Purpose:** Immutable audit trail of all portal mutations.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Actor
- [ ] role
- [ ] customer scope
- [ ] IP/session
- [ ] action
- [ ] resource
- [ ] before/after values
- [ ] request ID
- [ ] result
- [ ] timestamp
- [ ] filter/export
- [ ] retention policy

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/audit`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 077. VOS System Log

- **Group:** Admin Users, Roles & Audit
- **Route:** `/admin/system/vos-log`
- **Primary phase:** Phase 16
- **Purpose:** Expose VOS operational log read-only.
- **Source basis:** ** VOS System Log fields are documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Type Information/General/Error
- [ ] record time
- [ ] operating user
- [ ] event
- [ ] detail
- [ ] serial number
- [ ] link to related resource when identifiable

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/vos-log`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 078. System Parameters

- **Group:** System & Maintenance
- **Route:** `/admin/system/parameters`
- **Primary phase:** Phase 16
- **Purpose:** Search and edit allowed VOS system parameters.
- **Source basis:** ** VOS System Parameter exposes name/value/description. Writes are sensitive and [VERIFY-API].

### Feature TODO
- [ ] Parameter name/value/description
- [ ] Search by key
- [ ] Read-only by default
- [ ] Allowlisted editable parameters
- [ ] Validation by datatype/range
- [ ] Before/after diff
- [ ] Change ticket/reason
- [ ] Two-person approval for high-risk settings
- [ ] Rollback note

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/parameters`.
- [ ] Implement/verify `PATCH /api/v1/admin/system/parameters/{name}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 079. System Information

- **Group:** System & Maintenance
- **Route:** `/admin/system/info`
- **Primary phase:** Phase 16
- **Purpose:** Display connected VOS server information.
- **Source basis:** ** VOS System Information exists. Exact fields [VERIFY-API].

### Feature TODO
- [ ] Server/version/environment
- [ ] connected adapter
- [ ] time/timezone
- [ ] softswitch summary
- [ ] license/expiry only if available
- [ ] copy diagnostic bundle

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/info`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 080. Data Maintenance

- **Group:** System & Maintenance
- **Route:** `/admin/system/data-maintenance`
- **Primary phase:** Phase 16
- **Purpose:** View VOS historical table volumes and retention.
- **Source basis:** ** VOS documents system-log/history-alarm/payment/CDR/report tables and automatic cleanup. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Tabs: system logs, history alarms, payment records, CDR, reports
- [ ] Table name/date suffix
- [ ] data volume
- [ ] memo
- [ ] retention policy
- [ ] cleanup status
- [ ] no destructive action without explicit confirmation

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/data-maintenance`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 081. Performance Monitor

- **Group:** System & Maintenance
- **Route:** `/admin/system/performance`
- **Primary phase:** Phase 16
- **Purpose:** System-level operating performance.
- **Source basis:** ** VOS includes Operation Performance, Process Monitor and Server Monitor. Exact metrics [VERIFY-API].

### Feature TODO
- [ ] CPU/memory/process/load metrics only where available
- [ ] VOS operation performance data
- [ ] portal adapter latency
- [ ] CDR ingest lag
- [ ] historical charts

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/performance`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 082. Process Monitor

- **Group:** System & Maintenance
- **Route:** `/admin/system/processes`
- **Primary phase:** Phase 16
- **Purpose:** Read-only process status with controlled operational actions if supported.
- **Source basis:** ** VOS Process Monitor exists. [VERIFY-API]

### Feature TODO
- [ ] Process name/status
- [ ] uptime
- [ ] resource usage if available
- [ ] last restart
- [ ] alert state
- [ ] no restart button until vendor-safe API verified

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/processes`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 083. Server Monitor

- **Group:** System & Maintenance
- **Route:** `/admin/system/servers`
- **Primary phase:** Phase 16
- **Purpose:** Read-only VOS server state.
- **Source basis:** ** VOS Server Monitor exists. [VERIFY-API]

### Feature TODO
- [ ] Server list
- [ ] role
- [ ] status
- [ ] health indicators
- [ ] last update
- [ ] drill to alarms/performance

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/servers`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 084. Disaster Recovery

- **Group:** System & Maintenance
- **Route:** `/admin/system/disaster-recovery`
- **Primary phase:** Phase 16
- **Purpose:** Observe DR/tolerance state and equipment.
- **Source basis:** ** VOS documents Disaster Tolerance Status/Data/Equipment. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Status
- [ ] data state
- [ ] equipment
- [ ] replication/sync indicators if exposed
- [ ] last successful state
- [ ] alert integration
- [ ] read-only initial release

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/disaster-recovery`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 085. Work Calendar

- **Group:** System & Maintenance
- **Route:** `/admin/system/work-calendar`
- **Primary phase:** Phase 16
- **Purpose:** Manage VOS working/non-working calendars where needed.
- **Source basis:** ** VOS Work Calendar is documented. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Calendar name
- [ ] memo
- [ ] working/non-working periods
- [ ] usage references
- [ ] safe edit workflow

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/system/work-calendar`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 086. Portal API Clients

- **Group:** API, Integrations & Automation
- **Route:** `/admin/integrations/api-clients`
- **Primary phase:** Phase 16
- **Purpose:** Issue and control API access for customers/integrations.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Client/customer
- [ ] key ID
- [ ] secret shown once
- [ ] scopes
- [ ] IP allowlist
- [ ] rate limit
- [ ] created/last-used
- [ ] expiry
- [ ] rotate/revoke
- [ ] request statistics

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/integrations/api-clients`.
- [ ] Implement/verify `POST /api/v1/admin/integrations/api-clients`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 087. Webhook Endpoints

- **Group:** API, Integrations & Automation
- **Route:** `/admin/integrations/webhooks`
- **Primary phase:** Phase 15
- **Purpose:** Manage outbound event delivery.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Customer/integration
- [ ] URL
- [ ] events
- [ ] signing secret
- [ ] enabled state
- [ ] created/last success
- [ ] failure count
- [ ] test event
- [ ] rotate secret

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/integrations/webhooks`.
- [ ] Implement/verify `POST /api/v1/admin/integrations/webhooks`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 088. Webhook Delivery Log

- **Group:** API, Integrations & Automation
- **Route:** `/admin/integrations/webhook-deliveries`
- **Primary phase:** Phase 16
- **Purpose:** Troubleshoot event delivery.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Event ID/type
- [ ] customer
- [ ] endpoint
- [ ] attempt
- [ ] HTTP status
- [ ] latency
- [ ] response excerpt
- [ ] next retry
- [ ] manual retry
- [ ] payload viewer with secrets redacted

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/integrations/webhook-deliveries`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 089. VOS Web Access Control

- **Group:** API, Integrations & Automation
- **Route:** `/admin/integrations/vos-access`
- **Primary phase:** Phase 16
- **Purpose:** View/configure VOS external access controls.
- **Source basis:** ** VOS Interface Management > Web Access Control documents these fields. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Web service equipment
- [ ] directory name
- [ ] allowed IP
- [ ] memo
- [ ] change audit
- [ ] very restricted permission

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/integrations/vos-access`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 090. VOS Web Service Equipment

- **Group:** API, Integrations & Automation
- **Route:** `/admin/integrations/vos-equipment`
- **Primary phase:** Phase 16
- **Purpose:** Inspect VOS web-service access equipment.
- **Source basis:** ** VOS Interface Management > Web Service Equipment documents these fields. [VOS]/[VERIFY-API]

### Feature TODO
- [ ] Access name
- [ ] mark
- [ ] additional setting
- [ ] creation time
- [ ] access time
- [ ] access IP
- [ ] memo

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/integrations/vos-equipment`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 091. Integration Health

- **Group:** API, Integrations & Automation
- **Route:** `/admin/integrations/health`
- **Primary phase:** Phase 16
- **Purpose:** Monitor all external dependencies.
- **Source basis:** ** VOS parameters include external CDR send and phone online/offline transfer; complete setup requires verification. [HYBRID]

### Feature TODO
- [ ] VOS connectivity
- [ ] CDR event feed
- [ ] phone online/offline feed if configured
- [ ] payment providers
- [ ] email/SMS notification providers
- [ ] webhook queue
- [ ] last event and error

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/integrations/health`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 092. Support Tickets

- **Group:** Portal Operations
- **Route:** `/admin/support/tickets`
- **Primary phase:** Phase 15
- **Purpose:** Internal support queue connected to customer/call context.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Statuses, priority, category, assignee, SLA
- [ ] Link customer/gateway/CDR/call
- [ ] Internal notes vs customer replies
- [ ] attachments
- [ ] merge/close/reopen
- [ ] saved queues

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/support/tickets`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 093. Notification Policies

- **Group:** Portal Operations
- **Route:** `/admin/notifications/policies`
- **Primary phase:** Phase 15
- **Purpose:** Configure automated alerts.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Low balance
- [ ] gateway offline/online
- [ ] ASR drop
- [ ] high failure
- [ ] packet loss/latency
- [ ] payment result
- [ ] rate change
- [ ] account expiry
- [ ] threshold, duration and cool-down
- [ ] channels email/webhook/others
- [ ] customer opt-in rules

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/notification-policies`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 094. Notification Log

- **Group:** Portal Operations
- **Route:** `/admin/notifications/log`
- **Primary phase:** Phase 15
- **Purpose:** Delivery audit for all notifications.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Recipient
- [ ] event
- [ ] channel
- [ ] status
- [ ] attempts
- [ ] provider ID
- [ ] timestamp
- [ ] retry

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/notifications/log`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 095. Payment Providers

- **Group:** Portal Operations
- **Route:** `/admin/settings/payments`
- **Primary phase:** Phase 14
- **Purpose:** Configure customer top-up providers.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Provider enabled state
- [ ] currency support
- [ ] minimum/maximum deposit
- [ ] fee handling
- [ ] webhook secret health
- [ ] test mode indicator
- [ ] never display raw secrets after save

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/settings/payments`.
- [ ] Implement/verify `PUT /api/v1/admin/settings/payments/{provider}`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 096. Portal Branding

- **Group:** Portal Operations
- **Route:** `/admin/settings/branding`
- **Primary phase:** Phase 16
- **Purpose:** Control customer-facing brand.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Logo
- [ ] favicon
- [ ] product name
- [ ] support contact
- [ ] legal links
- [ ] timezone/currency defaults
- [ ] email sender identity
- [ ] preview

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/settings/branding`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.

## 097. Feature Flags

- **Group:** Portal Operations
- **Route:** `/admin/settings/features`
- **Primary phase:** Phase 16
- **Purpose:** Gradually enable portal modules by tenant.
- **Source basis:** ** [PORTAL]

### Feature TODO
- [ ] Feature name
- [ ] global state
- [ ] customer overrides
- [ ] dependency checks
- [ ] audit every change

### API / Backend TODO
- [ ] Implement/verify `GET /api/v1/admin/settings/features`.
- [ ] Define admin/client-safe response DTO.
- [ ] Validate all input server-side.
- [ ] Enforce RBAC and tenant/resource scope server-side.
- [ ] Add request ID and normalized error codes.
- [ ] Add upstream/VOS capability gate where applicable.
- [ ] Add audit event for all mutations.

### Data TODO
- [ ] Identify source of truth: PostgreSQL / ClickHouse / Redis / VOS / portal-derived.
- [ ] Add indexes/sort-key-friendly queries for expected filters.
- [ ] Add exact timestamp/timezone handling.
- [ ] Add exact money precision/currency handling where financial.
- [ ] Ensure customer pages cannot expose carrier cost/internal topology unless explicitly permitted.

### UX States
- [ ] Loading/skeleton.
- [ ] Empty/no-data.
- [ ] Filtered-no-results.
- [ ] Validation error.
- [ ] Permission denied.
- [ ] Upstream/VOS unavailable.
- [ ] Stale/degraded data with `data_as_of`.
- [ ] Mutation pending/success/failure/unknown outcome where relevant.

### Test TODO
- [ ] Unit/business logic.
- [ ] API validation.
- [ ] Authorization.
- [ ] Cross-tenant negative test.
- [ ] Upstream/VOS failure path where applicable.
- [ ] Mobile/responsive.
- [ ] Keyboard/accessibility.
- [ ] Performance test for table/report/live page where applicable.

### Done
- [ ] Design reviewed against `DESIGN.md`.
- [ ] API/OpenAPI documented.
- [ ] Observability added.
- [ ] Audit verified for mutations.
- [ ] UAT passed.
