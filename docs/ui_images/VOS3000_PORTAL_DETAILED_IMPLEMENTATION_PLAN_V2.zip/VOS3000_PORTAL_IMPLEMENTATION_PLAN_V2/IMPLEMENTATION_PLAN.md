# IMPLEMENTATION_PLAN.md

## Objective
Build a production VOS3000-backed Admin + Client portal capable of high-volume CDR, safe billing and realtime operations.

## Non-Negotiable Rules
- browser never connects to VOS directly
- VOS writes require verified capability
- PostgreSQL for transactional state
- ClickHouse for CDR/history
- Redis for live/cache only
- Redpanda for durable events
- all customer requests tenant-scoped server-side
- all financial changes idempotent and reconciled
- all high-risk writes audited

## Phase Index

| Phase | Name |
|---|---|
| 00 | Source Audit & Capability Freeze |
| 01 | Repository & Environment Foundation |
| 02 | PostgreSQL Business Data Foundation |
| 03 | Identity, MFA, RBAC & Tenant Isolation |
| 04 | VOS Adapter & Multi-Instance Integration |
| 05 | Redpanda Event Backbone |
| 06 | CDR Ingestion & Normalization |
| 07 | ClickHouse CDR Warehouse & Analytics |
| 08 | Realtime Calls, Gateway State & NOC |
| 09 | Admin Portal Foundation |
| 10 | Customer Portal Foundation |
| 11 | Accounts, Customers, Agents & User Management |
| 12 | Gateways, Phones, Routing & Network Tools |
| 13 | Rates, Packages, Number Management & Commercial Controls |
| 14 | Billing, Payments, Wallet, Settlement & Statements |
| 15 | Reports, Exports, API, Webhooks, Notifications & Support |
| 16 | System, Alarms, Observability, Security & DR |
| 17 | Migration, Load Test, UAT, Cutover & Hypercare |

## Execution Rule
Each phase file contains entry gate, implementation TODOs, engineering/UI/testing/documentation work and exit gate. Do not skip a phase gate just because code exists.

## Anti-Skip Controls
- Admin page checklist covers **97 pages**.
- Client page checklist covers **45 pages**.
- Combined traceability covers **142 pages**.
- Every page has backend, data, UX-state, authorization, test and done checklists.
- `VERIFY_API` VOS features remain disabled until contract-tested.

## References
- `12_REFERENCES/VOS3000_ADMIN_PORTAL_PRODUCT_DESIGN.md`
- `12_REFERENCES/VOS3000_CLIENT_PORTAL_PRODUCT_DESIGN.md`
- `12_REFERENCES/SOURCE_REFERENCE_MAP.md`
- `12_REFERENCES/VOS3000_2-1-8-0_2-1-8-05_English_Manual(VOS3000.Com)(1).pdf`
- `12_REFERENCES/DESIGN_REFERENCE_PASTED.md`
