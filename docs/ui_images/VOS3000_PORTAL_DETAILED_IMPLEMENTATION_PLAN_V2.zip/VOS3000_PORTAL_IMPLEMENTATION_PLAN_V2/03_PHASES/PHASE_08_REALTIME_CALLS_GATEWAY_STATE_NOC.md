# Phase 08 — Realtime Calls, Gateway State & NOC

## Objective
Build current-state plane using Redis and streams.

## Entry Gate
- [ ] Previous required phases complete.
- [ ] Required source/API assumptions verified.
- [ ] Owner and environment identified.
- [ ] Relevant product pages mapped to this phase.

## Detailed Implementation TODO
- [ ] Implement Current Call collector per VOS instance.
- [ ] Implement Online Mapping/Routing Gateway collectors.
- [ ] Implement Gateway Network quality collector.
- [ ] Design Redis key namespaces and TTLs.
- [ ] Compute state diffs and publish gateway state changes.
- [ ] Implement authorized WebSocket/SSE snapshot + incremental stream.
- [ ] Handle reconnect with fresh snapshot.
- [ ] Mark stale/degraded data when source polling fails.
- [ ] Implement live-call disconnect only if verified and admin-authorized.
- [ ] Load-test expected live concurrency without overloading VOS.

## Engineering Work
- [ ] Define/confirm PostgreSQL schema changes.
- [ ] Define/confirm ClickHouse schema/queries if applicable.
- [ ] Define Redis keys/TTL if applicable.
- [ ] Define Redpanda topics/events if applicable.
- [ ] Define API DTOs and OpenAPI.
- [ ] Define authorization/tenant rules.
- [ ] Define audit events.
- [ ] Add observability: metrics, logs, traces/request IDs.
- [ ] Add failure/degraded-state behavior.
- [ ] Add migration/backfill strategy when data changes.
- [ ] Add rollback/compensation strategy for mutations.

## UI Work
- [ ] Desktop layout.
- [ ] Tablet/mobile layout.
- [ ] Loading state.
- [ ] Empty state.
- [ ] Validation state.
- [ ] Permission-denied state.
- [ ] Integration degraded/stale state.
- [ ] Success/failure feedback.
- [ ] Accessibility and keyboard operation.
- [ ] DESIGN.md compliance.

## Tests
- [ ] Unit tests.
- [ ] API validation tests.
- [ ] Authorization tests.
- [ ] Tenant-isolation negative tests.
- [ ] Integration tests.
- [ ] Failure/retry tests.
- [ ] VOS contract tests if VOS-backed.
- [ ] Performance/load tests if high-volume.
- [ ] UAT scenarios.
- [ ] Regression tests.

## Documentation
- [ ] Update implementation plan.
- [ ] Update API/OpenAPI.
- [ ] Update event/schema docs.
- [ ] Update operations/runbook.
- [ ] Update capability matrix if VOS behavior changed.
- [ ] Record architecture decision if implementation differs from baseline.

## Exit Gate
- [ ] All scoped tasks complete.
- [ ] CI green.
- [ ] No unresolved critical security/data correctness defects.
- [ ] Observability active.
- [ ] Rollback/degraded behavior tested.
- [ ] Product owner/UAT sign-off where required.
- [ ] No `VERIFY_API` assumption silently enabled in production.
