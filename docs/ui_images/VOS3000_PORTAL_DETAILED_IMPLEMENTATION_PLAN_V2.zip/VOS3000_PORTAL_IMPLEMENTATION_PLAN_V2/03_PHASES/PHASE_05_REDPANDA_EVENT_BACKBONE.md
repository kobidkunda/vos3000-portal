# Phase 05 — Redpanda Event Backbone

## Objective
Build durable asynchronous processing.

## Entry Gate
- [ ] Previous required phases complete.
- [ ] Required source/API assumptions verified.
- [ ] Owner and environment identified.
- [ ] Relevant product pages mapped to this phase.

## Detailed Implementation TODO
- [ ] Create versioned event envelope.
- [ ] Create cdr.normalized.v1, gateway.state.v1, payment.*, webhook.delivery.v1, report.job.v1 topics.
- [ ] Choose partition keys based on tenant/VOS distribution and benchmark.
- [ ] Create DLQ topics and poison-event policy.
- [ ] Configure producer acknowledgements/retries.
- [ ] Create consumer group conventions.
- [ ] Add consumer lag metrics and alerts.
- [ ] Document retention based on measured traffic/recovery window.

## Engineering Work
- [ ] Define/confirm PostgreSQL schema changes.
- [ ] Define/confirm ClickHouse schema/queries if applicable.
- [ ] Define Redis keys/TTL if applicable.
- [ ] Define Redpanda topics/events if applicable.
- [ ] Define API DTOs and OpenAPI.
- [ ] Define authorization/tenant rules.
- [ ] Define audit events.
- [ ] Add observability: metrics, logs, traces/request IDs.
- [ ] Add failure/degraded-state behavior.
- [ ] Add migration/backfill strategy when data changes.
- [ ] Add rollback/compensation strategy for mutations.

## UI Work
- [ ] Desktop layout.
- [ ] Tablet/mobile layout.
- [ ] Loading state.
- [ ] Empty state.
- [ ] Validation state.
- [ ] Permission-denied state.
- [ ] Integration degraded/stale state.
- [ ] Success/failure feedback.
- [ ] Accessibility and keyboard operation.
- [ ] DESIGN.md compliance.

## Tests
- [ ] Unit tests.
- [ ] API validation tests.
- [ ] Authorization tests.
- [ ] Tenant-isolation negative tests.
- [ ] Integration tests.
- [ ] Failure/retry tests.
- [ ] VOS contract tests if VOS-backed.
- [ ] Performance/load tests if high-volume.
- [ ] UAT scenarios.
- [ ] Regression tests.

## Documentation
- [ ] Update implementation plan.
- [ ] Update API/OpenAPI.
- [ ] Update event/schema docs.
- [ ] Update operations/runbook.
- [ ] Update capability matrix if VOS behavior changed.
- [ ] Record architecture decision if implementation differs from baseline.

## Exit Gate
- [ ] All scoped tasks complete.
- [ ] CI green.
- [ ] No unresolved critical security/data correctness defects.
- [ ] Observability active.
- [ ] Rollback/degraded behavior tested.
- [ ] Product owner/UAT sign-off where required.
- [ ] No `VERIFY_API` assumption silently enabled in production.
