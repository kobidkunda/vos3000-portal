# Phase 07 — ClickHouse CDR Warehouse & Analytics

## Objective
Support millions/billions of CDR with fast tenant/time queries.

## Entry Gate
- [ ] Previous required phases complete.
- [ ] Required source/API assumptions verified.
- [ ] Owner and environment identified.
- [ ] Relevant product pages mapped to this phase.

## Detailed Implementation TODO
- [ ] Create canonical cdr_events schema.
- [ ] Benchmark partitioning and ORDER BY using real query patterns.
- [ ] Create hourly/daily customer rollups.
- [ ] Create gateway, destination and failure aggregates.
- [ ] Store sums/counts for recomputable ASR/ACD/PDD ratios.
- [ ] Implement tenant/time query guardrails.
- [ ] Implement cursor pagination.
- [ ] Add query timeout/cancellation and concurrency budgets.
- [ ] Validate aggregates against raw CDR and VOS samples.
- [ ] Define retention/TTL only after business approval.

## Engineering Work
- [ ] Define/confirm PostgreSQL schema changes.
- [ ] Define/confirm ClickHouse schema/queries if applicable.
- [ ] Define Redis keys/TTL if applicable.
- [ ] Define Redpanda topics/events if applicable.
- [ ] Define API DTOs and OpenAPI.
- [ ] Define authorization/tenant rules.
- [ ] Define audit events.
- [ ] Add observability: metrics, logs, traces/request IDs.
- [ ] Add failure/degraded-state behavior.
- [ ] Add migration/backfill strategy when data changes.
- [ ] Add rollback/compensation strategy for mutations.

## UI Work
- [ ] Desktop layout.
- [ ] Tablet/mobile layout.
- [ ] Loading state.
- [ ] Empty state.
- [ ] Validation state.
- [ ] Permission-denied state.
- [ ] Integration degraded/stale state.
- [ ] Success/failure feedback.
- [ ] Accessibility and keyboard operation.
- [ ] DESIGN.md compliance.

## Tests
- [ ] Unit tests.
- [ ] API validation tests.
- [ ] Authorization tests.
- [ ] Tenant-isolation negative tests.
- [ ] Integration tests.
- [ ] Failure/retry tests.
- [ ] VOS contract tests if VOS-backed.
- [ ] Performance/load tests if high-volume.
- [ ] UAT scenarios.
- [ ] Regression tests.

## Documentation
- [ ] Update implementation plan.
- [ ] Update API/OpenAPI.
- [ ] Update event/schema docs.
- [ ] Update operations/runbook.
- [ ] Update capability matrix if VOS behavior changed.
- [ ] Record architecture decision if implementation differs from baseline.

## Exit Gate
- [ ] All scoped tasks complete.
- [ ] CI green.
- [ ] No unresolved critical security/data correctness defects.
- [ ] Observability active.
- [ ] Rollback/degraded behavior tested.
- [ ] Product owner/UAT sign-off where required.
- [ ] No `VERIFY_API` assumption silently enabled in production.
