# Phase 15 — Reports, Exports, API, Webhooks, Notifications & Support

## Objective
Build the external platform surface.

## Entry Gate
- [ ] Previous required phases complete.
- [ ] Required source/API assumptions verified.
- [ ] Owner and environment identified.
- [ ] Relevant product pages mapped to this phase.

## Detailed Implementation TODO
- [ ] Async CDR/report jobs.
- [ ] Stream CSV.gz/Parquet output to object storage.
- [ ] XLSX row/size policy.
- [ ] Scheduled reports with timezone.
- [ ] Public /api/v1 and OpenAPI.
- [ ] API key scopes, IP restrictions and rate limits.
- [ ] API request logs with redaction.
- [ ] Signed HMAC webhooks and replay protection.
- [ ] Webhook retries/DLQ/SSRF controls.
- [ ] Notification center and preferences.
- [ ] Admin notification policies/log.
- [ ] Support ticket creation/detail/admin queue.

## Engineering Work
- [ ] Define/confirm PostgreSQL schema changes.
- [ ] Define/confirm ClickHouse schema/queries if applicable.
- [ ] Define Redis keys/TTL if applicable.
- [ ] Define Redpanda topics/events if applicable.
- [ ] Define API DTOs and OpenAPI.
- [ ] Define authorization/tenant rules.
- [ ] Define audit events.
- [ ] Add observability: metrics, logs, traces/request IDs.
- [ ] Add failure/degraded-state behavior.
- [ ] Add migration/backfill strategy when data changes.
- [ ] Add rollback/compensation strategy for mutations.

## UI Work
- [ ] Desktop layout.
- [ ] Tablet/mobile layout.
- [ ] Loading state.
- [ ] Empty state.
- [ ] Validation state.
- [ ] Permission-denied state.
- [ ] Integration degraded/stale state.
- [ ] Success/failure feedback.
- [ ] Accessibility and keyboard operation.
- [ ] DESIGN.md compliance.

## Tests
- [ ] Unit tests.
- [ ] API validation tests.
- [ ] Authorization tests.
- [ ] Tenant-isolation negative tests.
- [ ] Integration tests.
- [ ] Failure/retry tests.
- [ ] VOS contract tests if VOS-backed.
- [ ] Performance/load tests if high-volume.
- [ ] UAT scenarios.
- [ ] Regression tests.

## Documentation
- [ ] Update implementation plan.
- [ ] Update API/OpenAPI.
- [ ] Update event/schema docs.
- [ ] Update operations/runbook.
- [ ] Update capability matrix if VOS behavior changed.
- [ ] Record architecture decision if implementation differs from baseline.

## Exit Gate
- [ ] All scoped tasks complete.
- [ ] CI green.
- [ ] No unresolved critical security/data correctness defects.
- [ ] Observability active.
- [ ] Rollback/degraded behavior tested.
- [ ] Product owner/UAT sign-off where required.
- [ ] No `VERIFY_API` assumption silently enabled in production.
