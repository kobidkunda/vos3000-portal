# Redpanda Topics

- `cdr.normalized.v1`
- `cdr.normalized.dlq.v1`
- `gateway.state.v1`
- `payment.provider.v1`
- `payment.vos-credit.v1`
- `webhook.delivery.v1`
- `webhook.delivery.dlq.v1`
- `notification.delivery.v1`
- `report.job.v1`

All events:
- stable event_id
- schema_version
- occurred_at
- published_at
- tenant_id
- vos_instance_id
- correlation_id
- data
