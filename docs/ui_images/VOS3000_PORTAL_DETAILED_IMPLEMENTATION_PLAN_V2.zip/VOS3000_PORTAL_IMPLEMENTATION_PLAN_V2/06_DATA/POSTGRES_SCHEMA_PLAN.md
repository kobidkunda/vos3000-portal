# PostgreSQL Schema Plan

Domains:
- identity: users, sessions, MFA, roles, permissions
- tenancy: tenants, customer_users
- VOS registry: vos_instances, vos_accounts, vos_gateways, vos_phones, vos_rate_groups
- commands: configuration_changes, approvals
- money: deposits, payment_events, ledger_accounts, ledger_entries, vos_credit_commands, reconciliations
- developer: api_keys, scopes, webhook_endpoints, webhook_deliveries
- operations: notifications, support, report_jobs, downloads, audit_logs, sync_checkpoints

Important constraints:
- `(vos_instance_id, upstream_id)` unique per resource type
- tenant indexes on all tenant-owned tables
- provider event unique
- idempotency key scoped and unique
- ledger immutable
