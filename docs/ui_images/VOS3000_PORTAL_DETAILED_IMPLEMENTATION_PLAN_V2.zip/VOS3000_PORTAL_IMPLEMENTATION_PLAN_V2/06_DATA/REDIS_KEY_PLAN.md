# Redis Key Plan

Examples:
- `session:{hash}`
- `livecall:{vos}:{call}`
- `tenant:{tenant}:livecalls`
- `gateway:{vos}:{gateway}:state`
- `tenant:{tenant}:gateways`
- `ratelimit:api:{key}:{window}`
- `dashboard:{tenant}:{range}`
- `lock:job:{name}`

Every live/cache key gets bounded TTL.
Redis loss must be recoverable.
