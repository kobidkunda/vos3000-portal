# ClickHouse Schema Plan

Canonical CDR includes:
- event_id
- vos_instance_id
- tenant_id
- serial / Call-IDs
- account/agent
- caller/callee + rewritten values
- mapping/routing gateway
- caller/callee IP
- begin/connect/end
- actual/charged duration
- customer charge/tax
- carrier expense/tax
- call type
- area prefix/name
- billing method/mode
- PDD/connect delay
- termination reason/hangup side
- received_at
- schema_version

Start benchmark candidate:
`PARTITION BY toYYYYMM(begin_time)`
`ORDER BY (tenant_id, begin_time, mapping_gateway_id, callee, event_id)`

Do not freeze final ORDER BY without real query benchmark.
