# API Rules

Base: `/api/v1`

Every response:
- request_id
- typed data/error
- data_as_of for live/upstream data

Rules:
- cursor pagination for CDR/high-growth lists
- max date ranges
- rate limits
- tenant scope derived from auth, not request body
- customer/admin DTOs separate
- Idempotency-Key for financial/high-risk retryable create/actions
- OpenAPI must match implementation
